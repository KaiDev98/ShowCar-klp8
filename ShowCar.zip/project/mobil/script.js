// Popular cars data
const popularCars = [
  {
    name: "BMW X5",
    price: "$45,000",
    image:
      "https://images.unsplash.com/photo-1555215695-3004980ad54e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    rating: 4.8,
  },
  {
    name: "Audi A4",
    price: "$38,000",
    image:
      "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    rating: 4.7,
  },
  {
    name: "Mercedes C-Class",
    price: "$42,000",
    image:
      "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    rating: 4.9,
  },
  {
    name: "Tesla Model 3",
    price: "$35,000",
    image:
      "https://images.unsplash.com/photo-1560958089-b8a1929cea89?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    rating: 4.6,
  },
  {
    name: "Porsche 911",
    price: "$95,000",
    image:
      "https://images.unsplash.com/photo-1544636331-e26879cd4d9b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    rating: 4.9,
  },
  {
    name: "Range Rover",
    price: "$85,000",
    image:
      "https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    rating: 4.8,
  },
];

// Featured cars data
const featuredCars = [
  {
    name: "BMW M3",
    price: "$65,000",
    originalPrice: "$70,000",
    image:
      "https://images.unsplash.com/photo-1555215695-3004980ad54e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    badge: "Featured",
  },
  {
    name: "Audi RS6",
    price: "$78,000",
    originalPrice: "$82,000",
    image:
      "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    badge: "Hot Deal",
  },
  {
    name: "Mercedes AMG",
    price: "$72,000",
    originalPrice: "$75,000",
    image:
      "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    badge: "New",
  },
  {
    name: "Porsche Cayenne",
    price: "$68,000",
    originalPrice: "$73,000",
    image:
      "https://images.unsplash.com/photo-1544636331-e26879cd4d9b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
    badge: "Popular",
  },
];

// FAQ data
const faqs = [
  "How do I buy a car through your platform?",
  "What is the return policy for purchased vehicles?",
  "Do you provide financing options?",
  "How do I sell my car on your platform?",
  "What inspection services do you offer?",
];

// Function to create popular car cards
function createPopularCarCard(car) {
  return `
        <div class="car-card">
            <div class="car-image">
                <img src="${car.image}" alt="${car.name}">
                <button class="heart-btn" onclick="toggleFavorite(this)">
                    <i class="far fa-heart"></i>
                </button>
            </div>
            <div class="car-info">
                <div class="car-header">
                    <h3 class="car-name">${car.name}</h3>
                    <div class="rating">
                        <i class="fas fa-star star"></i>
                        <span>${car.rating}</span>
                    </div>
                </div>
                <p class="car-price">${car.price}</p>
                <button class="btn btn-primary view-btn">View Details</button>
            </div>
        </div>
    `;
}

// Function to create featured car cards
function createFeaturedCarCard(car) {
  return `
        <div class="featured-card">
            <div class="featured-image">
                <img src="${car.image}" alt="${car.name}">
                <span class="badge">${car.badge}</span>
                <button class="heart-btn" onclick="toggleFavorite(this)">
                    <i class="far fa-heart"></i>
                </button>
            </div>
            <div class="featured-info">
                <h3 class="featured-name">${car.name}</h3>
                <div class="price-info">
                    <span class="current-price">${car.price}</span>
                    <span class="original-price">${car.originalPrice}</span>
                </div>
                <button class="btn btn-primary view-btn">Buy Now</button>
            </div>
        </div>
    `;
}

// Function to create FAQ items
function createFaqItem(question) {
  return `
        <div class="faq-item" onclick="toggleFaq(this)">
            <span>${question}</span>
            <i class="fas fa-arrow-right"></i>
        </div>
    `;
}

// Function to toggle favorite status
function toggleFavorite(button) {
  const icon = button.querySelector("i");
  if (icon.classList.contains("far")) {
    icon.classList.remove("far");
    icon.classList.add("fas");
    icon.style.color = "#ef4444";
  } else {
    icon.classList.remove("fas");
    icon.classList.add("far");
    icon.style.color = "";
  }
}

// Function to toggle FAQ
function toggleFaq(item) {
  const icon = item.querySelector("i");
  if (icon.classList.contains("fa-arrow-right")) {
    icon.classList.remove("fa-arrow-right");
    icon.classList.add("fa-arrow-down");
    item.style.backgroundColor = "#f3f4f6";
  } else {
    icon.classList.remove("fa-arrow-down");
    icon.classList.add("fa-arrow-right");
    item.style.backgroundColor = "";
  }
}

// Function to handle mobile menu
function toggleMobileMenu() {
  const nav = document.querySelector(".nav");
  nav.style.display = nav.style.display === "flex" ? "none" : "flex";
}

// Function to handle smooth scrolling
function smoothScroll(target) {
  document.querySelector(target).scrollIntoView({
    behavior: "smooth",
  });
}

// Initialize the page
document.addEventListener("DOMContentLoaded", function () {
  // Populate popular cars
  const popularCarsGrid = document.getElementById("popularCarsGrid");
  popularCarsGrid.innerHTML = popularCars.map(createPopularCarCard).join("");

  // Populate featured cars
  const featuredCarsGrid = document.getElementById("featuredCarsGrid");
  featuredCarsGrid.innerHTML = featuredCars.map(createFeaturedCarCard).join("");

  // Populate FAQ
  const faqList = document.getElementById("faqList");
  faqList.innerHTML = faqs.map(createFaqItem).join("");

  // Add mobile menu functionality
  const mobileMenuBtn = document.querySelector(".mobile-menu-btn");
  if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener("click", toggleMobileMenu);
  }

  // Add scroll effect to header
  window.addEventListener("scroll", function () {
    const header = document.querySelector(".header");
    if (window.scrollY > 100) {
      header.style.boxShadow = "0 2px 10px rgba(0,0,0,0.1)";
    } else {
      header.style.boxShadow = "none";
    }
  });

  // Add click handlers for buttons
  document.querySelectorAll(".btn").forEach((button) => {
    button.addEventListener("click", function (e) {
      // Add ripple effect
      const ripple = document.createElement("span");
      const rect = button.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      const x = e.clientX - rect.left - size / 2;
      const y = e.clientY - rect.top - size / 2;

      ripple.style.width = ripple.style.height = size + "px";
      ripple.style.left = x + "px";
      ripple.style.top = y + "px";
      ripple.classList.add("ripple");

      button.appendChild(ripple);

      setTimeout(() => {
        ripple.remove();
      }, 600);
    });
  });

  // Newsletter subscription
  const newsletterForm = document.querySelector(".newsletter");
  if (newsletterForm) {
    const input = newsletterForm.querySelector("input");
    const button = newsletterForm.querySelector("button");

    button.addEventListener("click", function () {
      const email = input.value.trim();
      if (email && email.includes("@")) {
        alert("Thank you for subscribing!");
        input.value = "";
      } else {
        alert("Please enter a valid email address.");
      }
    });
  }
});

// Add CSS for ripple effect
const style = document.createElement("style");
style.textContent = `
    .btn {
        position: relative;
        overflow: hidden;
    }
    
    .ripple {
        position: absolute;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.3);
        transform: scale(0);
        animation: ripple-animation 0.6s linear;
        pointer-events: none;
    }
    
    @keyframes ripple-animation {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
