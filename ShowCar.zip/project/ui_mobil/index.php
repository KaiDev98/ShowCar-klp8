<?php
include '../koneksi.php'; //
?>

<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Honda New Brio 2025</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer>
      function switchTab(tab) {
        document
          .querySelectorAll(".tab-content")
          .forEach((el) => el.classList.add("hidden"));
        document.querySelector(`#${tab}`).classList.remove("hidden");
        document
          .querySelectorAll(".tab-button")
          .forEach((el) =>
            el.classList.remove("border-b-2", "border-orange-500")
          );
        document
          .querySelector(`[data-tab='${tab}']`)
          .classList.add("border-b-2", "border-orange-500");
      }

      function toggleAccordion(button) {
        const content = button.nextElementSibling;
        const allSections = document.querySelectorAll("#accordion > div > div");

        allSections.forEach((section) => {
          if (section !== content) {
            section.classList.add("hidden");
            section.previousElementSibling.querySelector("span").textContent =
              "+";
          }
        });

        content.classList.toggle("hidden");
        const icon = button.querySelector("span");
        icon.textContent = content.classList.contains("hidden") ? "+" : "−";
      }
    </script>
  </head>
  <body class="bg-gray-50 text-gray-800">
    <div class="max-w-6xl mx-auto p-4">
      <!-- Tabs Navigation -->
      <nav class="flex space-x-4 mb-6 border-b border-gray-300">
        <button
          data-tab="detail"
          onclick="switchTab('detail')"
          class="tab-button pb-2 border-b-2 border-orange-500"
        >
          Detail
        </button>
        <button
          data-tab="spesifikasi"
          onclick="switchTab('spesifikasi')"
          class="tab-button pb-2"
        >
          Spesifikasi
        </button>
        <button
          data-tab="foto-video"
          onclick="switchTab('foto-video')"
          class="tab-button pb-2"
        >
          Foto & Video
        </button>
      </nav>

      <!-- Detail Tab -->
      <div id="detail" class="tab-content">
        <h1 class="text-3xl font-bold mb-2">Nissan Gtr</h1>
        <p class="mb-4 text-sm font-semibold">Latar Belakang Nissan GTR </p>
        <p class="mb-4">
          Sama seperti Skyline GTR sebelumnya, Nissan GTR merupakan mobil sport berpenggerak empat roda dan menggunakan mesin 6 silinder twin-turbo, dan "darah" dari Skyline GTR terlihat jelas dari desain lampu belakangnya yang membulat.
        </p>
        <div class="flex flex-col md:flex-row items-center md:space-x-8">
          <img
            src="http://localhost/project/img/nissan.avif"
            alt="Honda Brio"
            class="w-80"
          />
          <div class="mt-4 md:mt-0">
            <p><strong>Harga :</strong></p>
            <p class="text-xl font-bold">Rp 170 Juta – 258 Juta</p>
            <a
              href="buy.php"
              class="inline-block mt-3 bg-orange-500 hover:bg-orange-600 text-white text-sm font-medium px-4 py-1.5 rounded-md shadow-sm transition"
            >
              Buy Sekarang
            </a>

            <div class="mt-4">
              <p class="mb-2 font-medium">Pilih Warna Mobil Anda:</p>
              <div class="flex space-x-2">
                <div class="w-6 h-6 rounded-full bg-gray-700"></div>
                <div class="w-6 h-6 rounded-full bg-red-600"></div>
                <div class="w-6 h-6 rounded-full bg-yellow-400"></div>
                <div class="w-6 h-6 rounded-full bg-black"></div>
                <div class="w-6 h-6 rounded-full bg-gray-300"></div>
              </div>
              <p class="text-xs text-gray-500 mt-1">
                * Warna dapat berbeda dengan mobil sebenarnya
              </p>
            </div>
          </div>
        </div>
      </div>

      <!-- Spesifikasi Tab -->
      <div id="spesifikasi" class="tab-content hidden">
        <div class="max-w-5xl mx-auto bg-white rounded-lg shadow p-6">
          <div class="mb-4">
            <h1 class="text-2xl font-bold">Nissan GTR</h1>
            <p class="text-gray-500">3800 cc | 2 Penumpang</p>
            <label
              for="tipe"
              class="block mt-4 text-sm font-medium text-gray-700"
              >Pilih Tipe Mobil</label
            >
            <select
              id="tipe"
              class="mt-1 block w-full border border-gray-300 rounded-md p-2"
            >
              <option>R35</option>
              <!-- <option>Satya E CVT</option>
              <option>RS M/T</option>
              <option>RS CVT</option> -->
            </select>
          </div>

          <!-- Accordion Section -->
          <div class="space-y-4" id="accordion">
            <div class="border rounded-md">
              <button
                class="w-full text-left px-4 py-3 font-semibold text-gray-800 bg-gray-100 hover:bg-gray-200 flex justify-between items-center"
                onclick="toggleAccordion(this)"
              >
                Mesin
                <span>+</span>
              </button>
              <div class="hidden px-4 py-2 text-sm text-gray-700">
                <table class="w-full text-sm">
                  <tbody>
                    <tr>
                      <td class="py-1">Diameter x Langkah</td>
                      <td>: 73,0 x 71,6</td>
                    </tr>
                    <tr>
                      <td class="py-1">Perbandingan Kompresi</td>
                      <td>: 10,1 : 1</td>
                    </tr>
                    <tr>
                      <td class="py-1">Jumlah/Tipe Silinder</td>
                      <td>: 4 Cylinder Inline</td>
                    </tr>
                    <tr>
                      <td class="py-1">Kapasitas Silinder</td>
                      <td>: PGM-FI</td>
                    </tr>
                    <tr>
                      <td class="py-1">Sistem Bahan Bakar</td>
                      <td>: 35 L</td>
                    </tr>
                    <tr>
                      <td class="py-1">Bahan Bakar</td>
                      <td>: Bensin</td>
                    </tr>
                    <tr>
                      <td class="py-1">Daya Maksimum</td>
                      <td>: 90 / 6.000</td>
                    </tr>
                    <tr>
                      <td class="py-1">Torsi Maksimum</td>
                      <td>: 110 / 4.800</td>
                    </tr>
                    <tr>
                      <td class="py-1">Tipe Mesin</td>
                      <td>: 1.2L SOHC, 16 Valve, i-VTEC + DBW</td>
                    </tr>
                    <tr>
                      <td class="py-1">Sistem Penggerak Roda</td>
                      <td>: FWD</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <!-- Tambahan Accordion -->
            <div class="border rounded-md">
              <button
                class="w-full text-left px-4 py-3 font-semibold text-gray-800 bg-gray-100 hover:bg-gray-200 flex justify-between items-center"
                onclick="toggleAccordion(this)"
              >
                Transmisi
                <span>+</span>
              </button>
              <div class="hidden px-4 py-2 text-sm text-gray-700">
                <p>Informasi tentang sistem transmisi...</p>
              </div>
            </div>

            <div class="border rounded-md">
              <button
                class="w-full text-left px-4 py-3 font-semibold text-gray-800 bg-gray-100 hover:bg-gray-200 flex justify-between items-center"
                onclick="toggleAccordion(this)"
              >
                Exterior
                <span>+</span>
              </button>
              <div class="hidden px-4 py-2 text-sm text-gray-700">
                <p>Detail tampilan luar mobil...</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Foto & Video Tab -->
      <div id="foto-video" class="tab-content hidden">
        <!-- Foto Section -->
        <div class="p-4 bg-white rounded-lg shadow">
          <h2 class="text-xl font-semibold mb-4">Foto</h2>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div class="text-center">
              <img
                src="https://libertywalk.co.jp/wp-content/uploads/2022/11/LB-WORKS-NISSAN-GT-R-R35-type-1-00005.jpg"
                alt="Taffeta White"
                class="w-full rounded-lg"
              />
            </div>
            <div class="text-center">
              <img
                src="https://libertywalk.co.jp/wp-content/uploads/2022/11/LB-WORKS-NISSAN-GT-R-R35-type-1-00002.jpg"
                alt="Electric Lime"
                class="w-full rounded-lg"
              />
              <!-- <p class="mt-2 text-sm text-gray-700">
                Satya S - Electric Lime Metallic
              </p> -->
            </div>
            <div class="text-center">
              <img
                src="https://libertywalk.co.jp/wp-content/uploads/2022/11/LB-WORKS-NISSAN-GT-R-R35-type-1-00001.jpg"
                alt="Rallye Red"
                class="w-full rounded-lg"
              />
              <!-- <p class="mt-2 text-sm text-gray-700">Satya S - Rallye Red</p> -->
            </div>
            <div class="text-center">
              <img
                src="https://libertywalk.co.jp/wp-content/uploads/2022/11/LB-WORKS-NISSAN-GT-R-R35-type-1-00003.jpg"
                alt="Meteoroid Gray"
                class="w-full rounded-lg"
              />
              <!-- <p class="mt-2 text-sm text-gray-700">
                Satya S - Meteoroid Gray Metallic
              </p> -->
            </div>
            <div class="text-center">
              <img
                src="https://libertywalk.co.jp/wp-content/uploads/2022/11/LB-WORKS-NISSAN-GT-R-R35-type-1-00004.jpg"
                alt="Crystal Black"
                class="w-full rounded-lg"
              />
            </div>
          </div>
        </div>

        <!-- Video Section -->
        <div class="p-4 bg-white rounded-lg shadow mt-6">
          <h2 class="text-xl font-semibold mb-4">Video</h2>
          <div class="relative w-full" style="padding-top: 56.25%">
            <iframe
              class="absolute top-0 left-0 w-full h-full rounded-lg"
              src="https://www.youtube.com/embed/fwPlIYflSUw?si=GCEj230CTtD5mO4v"
              title="Nissan GTR"
              frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen
            ></iframe>
          </div>
        </div>
      </div>
    </div>

    <footer
      class="bg-white border-t border-gray-200 text-center text-sm text-gray-600 py-4"
    >
      <p>&copy; 2025 Showroom Mobil. Hak Cipta Dilindungi.</p>
      <p class="mt-1">
        Dibuat dengan ❤️ menggunakan Tailwind dan bootstrap CSS.
      </p>
    </footer>
  </body>
</html>
