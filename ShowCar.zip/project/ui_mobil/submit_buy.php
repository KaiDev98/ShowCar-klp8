<?php
include '../koneksi.php'; // pastikan file koneksi sudah ada

// Ambil data dari form
$nama = $_POST['nama'];
$email = $_POST['email'];
$telepon = $_POST['telepon'];
$tipe_mobil = $_POST['tipe_mobil'];
$warna = $_POST['warna'];

// Query simpan ke tabel pembelian
$query = "INSERT INTO pembelian (nama_pembeli, email, no_hp, tipe_mobil, warna)
          VALUES ('$nama', '$email', '$telepon', '$tipe_mobil', '$warna')";

if (mysqli_query($conn, $query)) {
    echo "<script>
        alert('Pembelian berhasil! Silakan menunggu konfirmasi.');
        window.location.href = '../pengguna.php';
    </script>";
} else {
    echo "Gagal menyimpan data: " . mysqli_error($conn);
}
?>
