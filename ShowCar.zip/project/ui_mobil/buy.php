<!-- buy.php -->
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Form Pembelian</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 text-gray-800">
  <div class="max-w-xl mx-auto p-6 bg-white mt-10 rounded shadow">
    <h1 class="text-xl font-bold mb-4">Form Pembelian Mobil</h1>
    <form action="submit_buy.php" method="POST" class="space-y-4">
      <input type="text" name="nama" placeholder="Nama Lengkap" required class="w-full border p-2 rounded" />
      <input type="email" name="email" placeholder="Email" required class="w-full border p-2 rounded" />
      <input type="text" name="telepon" placeholder="No. Telepon" required class="w-full border p-2 rounded" />
      <select name="tipe_mobil" class="w-full border p-2 rounded" required>
        <option value="">Pilih Merk Mobil</option>
        <option value="Satya S M/T">Nissan</option>
        <option value="RS CVT">Mitsubishi</option>
        <option value="RS CVT">Chevrolet</option>
        <option value="RS CVT">Tesla</option>
        <option value="RS CVT">Jeep</option>
        <option value="RS CVT">Mercedez Benz</option>
      </select>
      <input type="text" name="warna" placeholder="Warna Mobil" required class="w-full border p-2 rounded" />
      <button type="submit" class="bg-orange-500 hover:bg-orange-600 text-white py-2 px-4 rounded">
        Submit
      </button>
    </form>
  </div>
</body>
</html>
