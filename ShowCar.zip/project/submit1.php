<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "showcar_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

$nama = $_POST['nama'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$tgl_lahir = $_POST['tgl_lahir'];
$gender = $_POST['gender'];
$alamat = $_POST['alamat'];
$pertanyaan = $_POST['pertanyaan'];

$sql = "INSERT INTO pembayaran (nama, email, phone, tgl_lahir, gender, alamat, pertanyaan)
VALUES (?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssss", $nama, $email, $phone, $tgl_lahir, $gender, $alamat, $pertanyaan);

if ($stmt->execute()) {
  // Redirect ke pengguna.php
  header("Location: pengguna.php");
  exit(); // Sangat penting agar tidak ada output tambahan
} else {
  echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
