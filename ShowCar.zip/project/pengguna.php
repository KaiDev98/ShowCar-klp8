<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}
?>

<?php
// Data mobil (dummy, bisa diganti dari database)
$cars = [
  [
    'brand' => 'Chevrolet',
    'name' => 'Chevrolet Spark',
    'image' => 'images/chevrolet.jpg'
  ],
  [
    'brand' => 'Nissan',
    'name' => 'Nissan GT-R',
    'image' => 'images/nissan.jpg'
  ],
  [
    'brand' => 'Mitsubishi',
    'name' => 'Mitsubishi Outlander',
    'image' => 'images/mitsubishi.jpg'
  ],
  [
    'brand' => 'Tesla',
    'name' => 'Tesla Model 3',
    'image' => 'images/tesla.jpg'
  ],
  [
    'brand' => 'Jeep',
    'name' => 'Jeep Wrangler',
    'image' => 'images/jeep.jpg'
  ],
  [
    'brand' => 'Mercedes',
    'name' => 'Mercedes Benz A-Class',
    'image' => 'images/mercedes.jpg'
  ],
];

// Ambil brand dari URL, default 'all'
$brand_filter = isset($_GET['brand']) ? strtolower($_GET['brand']) : 'all';
?>

<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Showroom Mobil</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <style>
      body {
        margin: 0;
      }

      .top-bar {
        background-color: #fff;
        padding: 10px 40px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 14px;
        border-bottom: 1px solid #ccc;
      }

      .top-bar .contact-info {
        display: flex;
        gap: 40px;
        align-items: center;
      }

      .top-bar i {
        margin-right: 6px;
      }

      .navbar {
        background-color: #111;
      }

      .navbar-brand {
        font-weight: bold;
        color: #fff !important;
      }

      .nav-link {
        color: #fff !important;
        margin-right: 15px;
      }

      .nav-link:hover {
        color: #f33 !important;
      }

      .user-dropdown {
        color: #fff;
      }

      /* car */
      .popular-cars {
        padding: 60px 30px;
        text-align: center;
      }

      .subtitle {
        color: red;
        font-weight: bold;
      }

      .title {
        font-size: 32px;
        font-weight: 700;
        margin: 10px 0 30px;
      }

      .filters {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        justify-content: center;
        margin-bottom: 40px;
      }

      .filters button {
        padding: 10px 18px;
        border: none;
        background: #f0f0f0;
        font-weight: 500;
        cursor: pointer;
        border-radius: 5px;
        transition: background 0.3s;
      }

      .filters button.active,
      .filters button:hover {
        background: #000;
        color: #fff;
      }

      .car-card {
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        overflow: hidden;
        text-align: left;
        background: #fff;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        opacity: 0;
        transform: translateY(30px);
        transition: opacity 0.6s ease, transform 0.6s ease;
      }

      .car-card.show {
        opacity: 1;
        transform: translateY(0);
      }

      .car-card img {
        width: 100%;
        height: 160px;
        object-fit: cover;
      }

      .car-info {
        padding: 16px;
      }

      .car-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-weight: bold;
      }

      .car-header h3 {
        font-size: 18px;
        margin: 0;
      }

      .heart {
        color: red;
        cursor: pointer;
      }

      .car-type {
        font-size: 13px;
        color: #888;
        margin: 4px 0 8px;
      }

      .description {
        font-size: 13px;
        color: #555;
        margin-bottom: 10px;
      }

      .specs {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        color: #666;
        margin-bottom: 12px;
      }

      .price-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .price {
        font-weight: bold;
        font-size: 15px;
      }

      .stars {
        color: orange;
        font-size: 13px;
      }

      .buy {
        background: red;
        color: white;
        border: none;
        padding: 6px 12px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 13px;
      }

      .view-more {
        margin-top: 20px;
      }

      .view-more button {
        background: #111;
        color: #fff;
        border: none;
        padding: 10px 18px;
        border-radius: 5px;
        cursor: pointer;
        font-weight: 500;
      }

      @media (max-width: 768px) {
        .car-grid {
          grid-template-columns: 1fr;
        }
      }

      .card-title {
        font-weight: bold;
      }

      .car-grid {
        display: grid;
        grid-template-columns: repeat(
          2,
          1fr
        ); /* Ganti dari auto-fill ke 2 kolom tetap */
        margin-bottom: 40px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0; /* Ganti dari 25px ke 0 */
        align-items: center; /* Supaya vertikal sejajar */
      }

      .car-grid {
        display: grid;
        grid-template-columns: repeat(
          4,
          1fr
        ); /* Ganti dari auto-fill ke 2 kolom tetap */
        gap: 25px;
        margin-bottom: 40px;
      }

      .car-grid > div {
        margin: 0;
        padding: 0;
      }

      .car-grid img {
        width: 100%;
        height: auto;
        display: block;
      }

      .car {
        border: 1px solid #ccc;
        padding: 15px;
        text-align: center;
        background-color: #fff;
        border-radius: 8px;
        transition: transform 0.2s;
      }

      .car:hover {
        transform: scale(1.02);
      }

      .buy-button {
        background: red;
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 8px;
        font-weight: bold;
        display: inline-block;
      }

      .read-more {
        color: #dc3545;
        font-weight: bold;
        text-decoration: none;
      }
      /* akhiran car */

      .filter-btn {
        padding: 10px 18px;
        border: none;
        background: #f0f0f0;
        font-weight: 500;
        cursor: pointer;
        border-radius: 5px;
        text-decoration: none;
        color: #000;
        transition: background 0.3s;
      }

      .filter-btn:hover {
        background: #ddd;
      }

      .filter-btn.active {
        background: #000;
        color: #fff;
      }

      .car-card,
.car {
  transition: transform 0.25s ease, box-shadow 0.25s ease, filter 0.25s ease;
  cursor: pointer;
}

.car-card:hover,
.car:hover {
  transform: scale(1.01) translateY(-2px);
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
  filter: brightness(1.01);
  z-index: 10;
}



/*berita otomotif*/
      header {
        background: #e30613;
        color: #fff;
        padding: 1.25rem 0;
        text-align: center;
        font-size: 1.75rem;
        font-weight: 600;
      }
      .card-img-top {
        height: 180px;
        object-fit: cover;
        border-radius: 0.5rem;
      }
      .meta {
        font-size: 0.875rem;
        color: #6c757d;
      }
      .meta .category {
        color: #28a745;
        margin-left: 0.5rem;
      }
      .link-more {
        display: inline-flex;
        align-items: center;
        text-transform: uppercase;
        font-weight: 600;
        text-decoration: none;
        color: #28a745;
        position: relative;
      }
      .link-more::after {
        content: "";
        position: absolute;
        bottom: -2px;
        left: 0;
        height: 2px;
        width: 0;
        background: #f2b400;
        transition: width 0.3s;
      }
      .link-more:hover::after {
        width: 100%;
      }

        .hero-section {
      background-color: red;
      color: white;
      padding: 60px 0;
      text-align: center;
    }

    .card-community {
      border: none;
      border-radius: 15px;
      box-shadow: 4px 4px 6px rgba(0,0,0,0.15);
      overflow: hidden;
      transition: transform 0.3s ease;
    }

    .card-community:hover {
      transform: translateY(-5px);
    }

    .card-img-top {
      background-color: #dcdcdc;
      height: 200px;
      object-fit: cover;
    }

    .card-title {
      font-weight: bold;
      text-shadow: 1px 1px 1px rgba(0,0,0,0.2);
    }
    </style>
  </head>
  <body>
    <!-- Top bar -->
    <div class="top-bar">
      <div class="logo">
        <h5 class="m-0">Socar</h5>
      </div>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand" href="#">Welcome!</a>
        <button
          class="navbar-toggler text-white"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarContent"
        >
          ☰
        </button>
        <div class="collapse navbar-collapse" id="navbarContent">
          <ul class="navbar-nav me-auto ms-4">
            <li class="nav-item"><a class="nav-link" href="#">HOME</a></li>
            <li class="nav-item">
              <a class="nav-link" href="#beritaotomotif">BERITA OTOMOTIF</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#komunitas">KOMUNITAS</a>
            </li>
            <li class="nav-item"><a class="nav-link" href="form_review.php">RATING REVIEW</a></li>
            <li class="nav-item">
              <a class="nav-link" href="showroom_forum/index.php">DISKUSI </a>
            </li>
          </ul>

          <!-- User dropdown -->
          <div class="dropdown">
            <a
              class="btn btn-dark dropdown-toggle"
              href="#"
              role="button"
              data-bs-toggle="dropdown"
            >
              <?= $_SESSION['nama_user'] ?? 'Akun' ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="#">Profil</a></li>
              <li><a class="dropdown-item" href="logout.php">Logout</a></li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!-- car -->
<!-- car section -->
<section class="popular-cars">
  <p class="subtitle">Mobil Baru!</p>
  <h2 class="title">Daftar Mobil yang tersedia!</h2>
  <?php
// Tentukan merk saat ini
$current_brand = isset($_GET['brand']) ? $_GET['brand'] : 'all';
?>

<div class="filters">
  <!-- Show All harus selalu mengarah ke pengguna.php -->
  <a href="pengguna.php" class="filter-btn <?= $current_brand == 'all' ? 'active' : '' ?>">Show All</a>
  
  <?php
  // Daftar semua merk mobil
  $brands = ['chevrolet', 'nissan', 'mitsubishi', 'tesla', 'jeep', 'mb'];

  foreach ($brands as $brand) {
      // Tentukan link tujuan berdasarkan file PHP
      $file_path = "$brand.php";
      $link = file_exists($file_path) ? $file_path : "pengguna.php?brand=$brand";
      
      // Tambahkan kelas active jika saat ini berada di brand yang dipilih
      $active_class = $current_brand == $brand ? 'active' : '';
      
      echo "<a href='$link' class='filter-btn $active_class'>".ucfirst($brand)."</a>";
  }
  ?>
</div>
</section>

      <div class="car-grid">
        <!-- Repeat this block for each car -->
        <div class="car-card">
          <img src="img/nissan.avif" alt="Nissan GT-R" />
          <div class="car-info">
            <div class="car-header">
              <h3>Nissan GT-R</h3>
              <i class="fa-solid fa-heart heart"></i>
            </div>
            <p class="car-type">Sport</p>
            <p class="description">
              Lorem ipsum dolor sit amet consectetur. Nec duis elit in integer
              urna facilisi eget nibh amet.
            </p>
            <div class="specs">
              <span>2023</span>
              <span>Manual</span>
              <span>2 People</span>
            </div>
            <div class="price-row">
              <span class="price">Rp 170 Juta – 258 Juta</span>
              <span class="stars"><i class="fa-solid fa-star"></i> 5</span>
              <a href="ui_mobil/index.php" class="buy-button">Buy</a>
            </div>
          </div>
        </div>
        <!-- Tambahkan lebih banyak mobil dengan blok ini -->
        <div class="car-card">
          <img
            src="https://images.unsplash.com/photo-1724930993094-293f544e72dd?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8bWl0c3ViaXNoaSUyMGNhcnxlbnwwfHwwfHx8MA%3D%3D"
            alt="Mitsubishi"
          />
          <div class="car-info">
            <div class="car-header">
              <h3>Mitsubishi</h3>
              <i class="fa-solid fa-heart heart"></i>
            </div>
            <p class="car-type">Sport</p>
            <p class="description">
              Lorem ipsum dolor sit amet consectetur. Nec duis elit in integer
              urna facilisi eget nibh amet.
            </p>
            <div class="specs">
              <span>2023</span>
              <span>Manual</span>
              <span>2 People</span>
            </div>
            <div class="price-row">
              <span class="price">Rp 270,1 - 337,8 Juta</span>
              <span class="stars"><i class="fa-solid fa-star"></i> 5</span>
              <a href="ui_mobil/mitsubishi.php" class="buy-button">Buy</a>
            </div>
          </div>
        </div>
        <div class="car-card">
          <img
            src="https://imgcdn.oto.com/medium/gallery/exterior/5/1679/chevrolet-trax-65360.jpg"
            alt="Chevrolet"
          />
          <div class="car-info">
            <div class="car-header">
              <h3>Chevrolet</h3>
              <i class="fa-solid fa-heart heart"></i>
            </div>
            <p class="car-type">Sport</p>
            <p class="description">
              Lorem ipsum dolor sit amet consectetur. Nec duis elit in integer
              urna facilisi eget nibh amet.
            </p>
            <div class="specs">
              <span>2023</span>
              <span>Manual</span>
              <span>2 People</span>
            </div>
            <div class="price-row">
              <span class="price">270,1 - 337,8 Juta</span>
              <span class="stars"><i class="fa-solid fa-star"></i> 5</span>
              <a href="ui_mobil/chevrolet.php" class="buy-button">Buy</a>
            </div>
          </div>
        </div>
        <div class="car-card">
          <img
            src="https://imgcdn.oto.com/medium/gallery/exterior/133/2222/tesla-model-x-58324.jpg"
            alt="tesla"
          />
          <div class="car-info">
            <div class="car-header">
              <h3>Tesla</h3>
              <i class="fa-solid fa-heart heart"></i>
            </div>
            <p class="car-type">Sport</p>
            <p class="description">
              Lorem ipsum dolor sit amet consectetur. Nec duis elit in integer
              urna facilisi eget nibh amet.
            </p>
            <div class="specs">
              <span>2023</span>
              <span>Manual</span>
              <span>2 People</span>
            </div>
            <div class="price-row">
              <span class="price">Rp 270,1 - 337,8 Juta</span>
              <span class="stars"><i class="fa-solid fa-star"></i> 5</span>
              <a href="ui_mobil/tesla.php" class="buy-button">Buy</a>
            </div>
          </div>
        </div>
        <div class="car-card">
          <img
            src="https://imgcdn.oto.com/medium/gallery/exterior/19/3186/jeep-wrangler-50073.jpg"
            alt="Nissan GT-R"
          />
          <div class="car-info">
            <div class="car-header">
              <h3>Jeep</h3>
              <i class="fa-solid fa-heart heart"></i>
            </div>
            <p class="car-type">Sport</p>
            <p class="description">
              Lorem ipsum dolor sit amet consectetur. Nec duis elit in integer
              urna facilisi eget nibh amet.
            </p>
            <div class="specs">
              <span>2023</span>
              <span>Manual</span>
              <span>2 People</span>
            </div>
            <div class="price-row">
              <span class="price">Rp  2,389 Milyar</span>
              <span class="stars"><i class="fa-solid fa-star"></i> 5</span>
              <a href="ui_mobil/jeep.php" class="buy-button">Buy</a>
            </div>
          </div>
        </div>
        <div class="car-card">
          <img
            src="https://imgcdn.oto.com/medium/gallery/exterior/25/2197/mercedes-benz-gle-class-2019-91640.jpg"
            alt="Nissan GT-R"
          />
          <div class="car-info">
            <div class="car-header">
              <h3>Mercedez benz</h3>
              <i class="fa-solid fa-heart heart"></i>
            </div>
            <p class="car-type">Sport</p>
            <p class="description">
              Lorem ipsum dolor sit amet consectetur. Nec duis elit in integer
              urna facilisi eget nibh amet.
            </p>
            <div class="specs">
              <span>2023</span>
              <span>Manual</span>
              <span>2 People</span>
            </div>
            <div class="price-row">
              <span class="price">Rp 2,27 - 3,55 Milyar</span>
              <span class="stars"><i class="fa-solid fa-star"></i> 5</span>
              <a href="ui_mobil/mb.php" class="buy-button">Buy</a>
            </div>
          </div>
        </div>
        <div class="car-card">
          <img
            src="https://imgcdn.oto.com/large/gallery/exterior/14/2482/honda-civic-rs-front-angle-low-view-530222.jpg"
            alt="Nissan GT-R"
          />
          <div class="car-info">
            <div class="car-header">
              <h3>honda</h3>
              <i class="fa-solid fa-heart heart"></i>
            </div>
            <p class="car-type">Sport</p>
            <p class="description">
              Lorem ipsum dolor sit amet consectetur. Nec duis elit in integer
              urna facilisi eget nibh amet.
            </p>
            <div class="specs">
              <span>2023</span>
              <span>Manual</span>
              <span>2 People</span>
            </div>
            <div class="price-row">
              <span class="price">Rp 699 Juta</span>
              <span class="stars"><i class="fa-solid fa-star"></i> 5</span>
              <a href="ui_mobil/honda.php" class="buy-button">Buy</a>
            </div>
          </div>
        </div>
        <div class="car-card">
          <img
            src="https://imgcdn.oto.com/large/gallery/exterior/31/2340/porsche-taycan-front-angle-low-view-450516.jpg"
            alt="Nissan GT-R"
          />
          <div class="car-info">
            <div class="car-header">
              <h3>Porsche</h3>
              <i class="fa-solid fa-heart heart"></i>
            </div>
            <p class="car-type">Sport</p>
            <p class="description">
              Lorem ipsum dolor sit amet consectetur. Nec duis elit in integer
              urna facilisi eget nibh amet.
            </p>
            <div class="specs">
              <span>2023</span>
              <span>Manual</span>
              <span>2 People</span>
            </div>
            <div class="price-row">
              <span class="price">Rp 699 Juta</span>
              <span class="stars"><i class="fa-solid fa-star"></i> 5</span>
              <a href="ui_mobil/porsche.php" class="buy-button">Buy</a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- akhiran car -->

    <!-- awalan berita -->
         <header id="beritaotomotif"  >Berita Otomotif</header>

    <div class="container py-4">
      <div class="row g-4">
        <!-- ulangi blok ini sebanyak 8 kali, isi src gambar, tanggal, kategori, dan judul sesuai kebutuhan -->
        <div class="col-12 col-md-6 col-lg-3">
          <div class="card border-0 h-100 d-flex flex-column">
            <img
              src="https://www.kallatoyota.co.id/storage/images/newstips/1746859630i-jpg"
              class="card-img-top"
              alt="Berita 1"
            />
            <div class="card-body d-flex flex-column">
              <div class="meta mb-1">
                6 May 2025
                <span class="category">Event</span>
              </div>
              <h6 class="card-title flex-grow-1">
                Special di Toyota Eco Fest, DP Bisa Bayar 2× Melalui Sm…
              </h6>
              <a href="#" class="link-more mt-3">
                Find Out More <i class="bi bi-arrow-right-short"></i>
              </a>
            </div>
          </div>
        </div>
        <!-- 2 -->
        <div class="col-12 col-md-6 col-lg-3">
          <div class="card border-0 h-100 d-flex flex-column">
            <img
              src="https://www.kallatoyota.co.id/storage/images/newstips/1742948057i-jpg"
              class="card-img-top"
              alt="Berita 2"
            />
            <div class="card-body d-flex flex-column">
              <div class="meta mb-1">
                26 March 2025
                <span class="category">Tips</span>
              </div>
              <h6 class="card-title flex-grow-1">
                Puncak Arus Mudik dan Balik Lebaran Sudah Diprediksi, S…
              </h6>
              <a href="#" class="link-more mt-3">
                Find Out More <i class="bi bi-arrow-right-short"></i>
              </a>
            </div>
          </div>
        </div>
        <!-- 3 -->
        <div class="col-12 col-md-6 col-lg-3">
          <div class="card border-0 h-100 d-flex flex-column">
            <img
              src="https://www.kallatoyota.co.id/storage/images/newstips/1742947614i-jpg"
              class="card-img-top"
              alt="Berita 3"
            />
            <div class="card-body d-flex flex-column">
              <div class="meta mb-1">
                26 March 2025
                <span class="category">Promo</span>
              </div>
              <h6 class="card-title flex-grow-1">
                Kalla Toyota Hadirkan Promo Spesial! Diskon Own Risk &…
              </h6>
              <a href="#" class="link-more mt-3">
                Find Out More <i class="bi bi-arrow-right-short"></i>
              </a>
            </div>
          </div>
        </div>
        <!-- 4 -->
        <div class="col-12 col-md-6 col-lg-3">
          <div class="card border-0 h-100 d-flex flex-column">
            <img
              src="https://www.kallatoyota.co.id/storage/images/newstips/1742350242i-jpg"
              class="card-img-top"
              alt="Berita 4"
            />
            <div class="card-body d-flex flex-column">
              <div class="meta mb-1">
                17 March 2025
                <span class="category">Event</span>
              </div>
              <h6 class="card-title flex-grow-1">
                Berlebaran dengan Toyota Baru, Dapatkan Beragam Promo M…
              </h6>
              <a href="#" class="link-more mt-3">
                Find Out More <i class="bi bi-arrow-right-short"></i>
              </a>
            </div>
          </div>
        </div>

        <!-- baris ke-2: copy-paste dan ganti konten -->
        <div class="col-12 col-md-6 col-lg-3">
          <div class="card border-0 h-100 d-flex flex-column">
            <img
              src="https://www.kallatoyota.co.id/storage/images/newstips/1742349733i-jpg"
              class="card-img-top"
              alt="Berita 5"
            />
            <div class="card-body d-flex flex-column">
              <div class="meta mb-1">
                17 March 2025
                <span class="category">CSR</span>
              </div>
              <h6 class="card-title flex-grow-1">
                Kalla Toyota Serahkan Bantuan CSR Puluhan Tempat Sampah…
              </h6>
              <a href="#" class="link-more mt-3">
                Find Out More <i class="bi bi-arrow-right-short"></i>
              </a>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-3">
          <div class="card border-0 h-100 d-flex flex-column">
            <img
              src="https://www.kallatoyota.co.id/storage/images/newstips/1742182603i-jpg"
              class="card-img-top"
              alt="Berita 6"
            />
            <div class="card-body d-flex flex-column">
              <div class="meta mb-1">
                11 March 2025
                <span class="category">Trending</span>
              </div>
              <h6 class="card-title flex-grow-1">
                Toyota Hilux Rangga: Mitra Tangguh Pengusaha Sulawesi,…
              </h6>
              <a href="#" class="link-more mt-3">
                Find Out More <i class="bi bi-arrow-right-short"></i>
              </a>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-3">
          <div class="card border-0 h-100 d-flex flex-column">
            <img
              src="https://www.kallatoyota.co.id/storage/images/newstips/1742182220i-jpg"
              class="card-img-top"
              alt="Berita 7"
            />
            <div class="card-body d-flex flex-column">
              <div class="meta mb-1">
                16 March 2025
                <span class="category">Event</span>
              </div>
              <h6 class="card-title flex-grow-1">
                New Camry Hybrid Resmi Mengaspal di Makassar. Hadir den…
              </h6>
              <a href="#" class="link-more mt-3">
                Find Out More <i class="bi bi-arrow-right-short"></i>
              </a>
            </div>
          </div>
        </div>
        <div class="col-12 col-md-6 col-lg-3">
          <div class="card border-0 h-100 d-flex flex-column">
            <img
              src="https://www.kallatoyota.co.id/storage/images/newstips/1741653207i-jpg"
              class="card-img-top"
              alt="Berita 8"
            />
            <div class="card-body d-flex flex-column">
              <div class="meta mb-1">
                11 March 2025
                <span class="category">Event</span>
              </div>
              <h6 class="card-title flex-grow-1">
                Jangan Lewatkan! Ramadan Super Sale by Kalla Toyota Had…
              </h6>
              <a href="#" class="link-more mt-3">
                Find Out More <i class="bi bi-arrow-right-short"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
     <!-- akhiran berita -->

     <!-- komunitas  -->
       <div id="komunitas" class="hero-section">
    <h1 class="fw-bold">Komunitas</h1>
    <p class="fs-5">Bergabunglah Dengan Para Pecinta Mobil</p>
  </div>

  <div class="container my-5">
    <h3 class="mb-4 fw-bold">Komunitas Populer</h3>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card card-community">
          <img src="https://images.unsplash.com/photo-1581862142388-23e1c52ca091?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dG95b3RhfGVufDB8fDB8fHww" class="card-img-top" alt="Toyota Lovers" />
          <div class="card-body bg-light">
            <h5 class="card-title">Toyota Lovers</h5>
            <p class="card-text">Komunitas penggemar mobil Toyota. Diskusi, modifikasi, gathering, dan berbagi pengalaman.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-community">
          <img src="https://images.unsplash.com/photo-1577436864274-bcd551d82b6b?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8aG9uZGF8ZW58MHx8MHx8fDA%3D" class="card-img-top" alt="Honda Lovers" />
          <div class="card-body bg-light">
            <h5 class="card-title">Honda Lovers</h5>
            <p class="card-text">Diskusi komunitas Honda se-Indonesia. Tuning, racing, hingga acara komunitas.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card card-community">
          <img src="https://images.unsplash.com/photo-1592399438478-4d4e2664a323?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8bWl0c3ViaXNoaXxlbnwwfHwwfHx8MA%3D%3D" class="card-img-top" alt="Mitsubishi Club" />
          <div class="card-body bg-light">
            <h5 class="card-title">Mitsubishi Club</h5>
            <p class="card-text">Forum Mitsubishi Indonesia untuk networking, tips perawatan, dan touring.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
      <!-- akhiran komunitas -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
      document.addEventListener("DOMContentLoaded", () => {
        const cards = document.querySelectorAll(".car-card");

        cards.forEach((card, index) => {
          // Delay animasi sedikit berdasarkan urutan
          setTimeout(() => {
            card.classList.add("show");
          }, index * 150); // Delay 150ms antar card
        });
      });

      
    </script>

        <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
    
  </body>
</html>
