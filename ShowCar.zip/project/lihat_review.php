<?php
$conn = new mysqli("localhost", "root", "", "showcar_db");

$sql = "SELECT r.*, m.nama_mobil FROM review r 
        JOIN mobil m ON r.car_id = m.id 
        ORDER BY r.created_at DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Review Pengguna</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">
  <h2>Review dari Pengguna</h2>
  <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
    <?php while($row = $result->fetch_assoc()): ?>
    <div class="col">
      <div class="card shadow-sm h-100">
        <div class="card-body">
          <h5 class="card-title"><?= htmlspecialchars($row['nama_mobil']) ?></h5>
          <div class="text-warning mb-2">
            <?= str_repeat("★", $row['rating']) ?>
            <?= str_repeat("☆", 5 - $row['rating']) ?>
          </div>
          <p class="card-text"><?= htmlspecialchars($row['comment']) ?></p>
        </div>
        <div class="card-footer text-muted small">
          <?= htmlspecialchars($row['user_name']) ?> - <?= date("d M Y", strtotime($row['created_at'])) ?>
        </div>
      </div>
    </div>
    <?php endwhile; ?>
  </div>
</body>
</html>
