<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Booking Test Drive</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    body {
  font-family: sans-serif;
  background: #f0f0f0;
  margin: 0;
  padding: 0;
}

.container {
  max-width: 600px;
  margin: 30px auto;
  background: white;
  padding: 20px;
  border-radius: 10px;
}

h1, h2 {
  text-align: center;
  color: #e60000;
}

form {
  display: flex;
  flex-direction: column;
}

label {
  margin-top: 10px;
}

input, select, textarea {
  padding: 10px;
  margin-top: 5px;
  border-radius: 5px;
  border: 1px solid #ccc;
}

textarea {
  resize: vertical;
}

.buttons {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}

button {
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button[type="submit"] {
  background-color: red;
  color: white;
}

button[type="reset"] {
  background-color: lightgray;
}

  </style>
</head>
<body>
  <div class="container">
    <h1>Booking Test Drive</h1>
    <form action="submit1.php" method="POST">
      <h2>Informasi Pribadi</h2>
      <label>Nama Lengkap*</label>
      <input type="text" name="nama" required />

      <label>Email*</label>
      <input type="email" name="email" required />

      <label>No. Handphone*</label>
      <input type="text" name="phone" required />

      <label>Tanggal Lahir*</label>
      <input type="date" name="tgl_lahir" required />

      <label>Gender*</label>
      <select name="gender" required>
        <option value="">Pilih Gender</option>
        <option value="Laki-laki">Laki-laki</option>
        <option value="Perempuan">Perempuan</option>
      </select>

      <label>Alamat*</label>
      <textarea name="alamat" required></textarea>

      <h2>Informasi Booking Test Drive</h2>
      <label>Pertanyaan*</label>
      <textarea name="pertanyaan" required></textarea>

      <label>
        <input type="checkbox" required />
        Saya telah membaca dan menyetujui Kebijakan Privasi.
      </label>

      <div class="buttons">
        <button type="submit">Submit</button>
        <button type="reset">Reset</button>
      </div>
    </form>
  </div>
</body>
</html>
