<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "showcar_db");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari form
$username = $_POST['username'];
$password = $_POST['password'];
$confirm = $_POST['confirm_password'];
$phone = $_POST['phone'];

// Validasi password
if ($password !== $confirm) {
    echo "Kata sandi tidak cocok!";
    exit;
}

// Enkripsi password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Simpan ke database
$sql = "INSERT INTO users (username, password, phone) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $username, $hashedPassword, $phone);

if ($stmt->execute()) {
    header("Location: login.html"); // Redirect ke login jika berhasil
} else {
    echo "Gagal mendaftar: " . $stmt->error;
}

$conn->close();
?>
