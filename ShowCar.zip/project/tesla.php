<?php session_start(); ?>

<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Shocar</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <style>
      body {
        margin: 0;
      }

      .top-bar {
        background-color: #fff;
        padding: 10px 40px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 14px;
        border-bottom: 1px solid #ccc;
      }

      .top-bar .contact-info {
        display: flex;
        gap: 40px;
        align-items: center;
      }

      .top-bar i {
        margin-right: 6px;
      }

      .navbar {
        background-color: #111;
      }

      .navbar-brand {
        font-weight: bold;
        color: #fff !important;
      }

      .nav-link {
        color: #fff !important;
        margin-right: 15px;
      }

      .nav-link:hover {
        color: #f33 !important;
      }

      .user-dropdown {
        color: #fff;
      }

      /* car */
      .popular-cars {
        padding: 60px 30px;
        text-align: center;
      }

      .subtitle {
        color: red;
        font-weight: bold;
      }

      .title {
        font-size: 32px;
        font-weight: 700;
        margin: 10px 0 30px;
      }

      .filters {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        justify-content: center;
        margin-bottom: 40px;
      }

      .filters button {
        padding: 10px 18px;
        border: none;
        background: #f0f0f0;
        font-weight: 500;
        cursor: pointer;
        border-radius: 5px;
        transition: background 0.3s;
      }

      .filters button.active,
      .filters button:hover {
        background: #000;
        color: #fff;
      }

      .car-card {
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        overflow: hidden;
        text-align: left;
        background: #fff;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
      }

      .car-card img {
        width: 100%;
        height: 160px;
        object-fit: cover;
      }

      .car-info {
        padding: 16px;
      }

      .car-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-weight: bold;
      }

      .car-header h3 {
        font-size: 18px;
        margin: 0;
      }

      .heart {
        color: red;
        cursor: pointer;
      }

      .car-type {
        font-size: 13px;
        color: #888;
        margin: 4px 0 8px;
      }

      .description {
        font-size: 13px;
        color: #555;
        margin-bottom: 10px;
      }

      .specs {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        color: #666;
        margin-bottom: 12px;
      }

      .price-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .price {
        font-weight: bold;
        font-size: 15px;
      }

      .stars {
        color: orange;
        font-size: 13px;
      }

      .buy {
        background: red;
        color: white;
        border: none;
        padding: 6px 12px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 13px;
      }

      .view-more {
        margin-top: 20px;
      }

      .view-more button {
        background: #111;
        color: #fff;
        border: none;
        padding: 10px 18px;
        border-radius: 5px;
        cursor: pointer;
        font-weight: 500;
      }

      @media (max-width: 768px) {
        .car-grid {
          grid-template-columns: 1fr;
        }
      }

      .card-title {
        font-weight: bold;
      }

      .car-grid {
        display: grid;
        grid-template-columns: repeat(
          2,
          1fr
        ); /* Ganti dari auto-fill ke 2 kolom tetap */
        margin-bottom: 40px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0; /* Ganti dari 25px ke 0 */
        align-items: center; /* Supaya vertikal sejajar */
      }

      .car-grid {
        display: grid;
        grid-template-columns: repeat(
          4,
          1fr
        ); /* Ganti dari auto-fill ke 2 kolom tetap */
        gap: 25px;
        margin-bottom: 40px;
      }

      .car-grid > div {
        margin: 0;
        padding: 0;
      }

      .car-grid img {
        width: 100%;
        height: auto;
        display: block;
      }

      .car {
        border: 1px solid #ccc;
        padding: 15px;
        text-align: center;
        background-color: #fff;
        border-radius: 8px;
        transition: transform 0.2s;
      }

      .car:hover {
        transform: scale(1.02);
      }

      .buy-button,
      .view-more button {
        background-color: #dc3545;
        color: #fff;
        border: none;
        padding: 10px 15px;
        cursor: pointer;
        border-radius: 5px;
      }

      .read-more {
        color: #dc3545;
        font-weight: bold;
        text-decoration: none;
      }
      /* akhiran car */

            .filter-btn {
        display: inline-block;
        padding: 10px 18px;
        border: none;
        background: #f0f0f0;
        font-weight: 500;
        cursor: pointer;
        border-radius: 5px;
        text-decoration: none;
        color: #000;
        transition: background 0.3s;
      }

      .filter-btn.active,
      .filter-btn:hover {
        background: #000;
        color: #fff;
      }

      /* Keyframes animasi dari kiri */
@keyframes slideInLeft {
  0% {
    opacity: 0;
    transform: translateX(-60px);
  }
  100% {
    opacity: 1;
    transform: translateX(0);
  }
}

/* Terapkan animasi ke setiap card mobil */
.car-card,
.car {
  opacity: 0;
  animation: slideInLeft 0.6s ease-out forwards;
}

/* Delay animasi agar muncul satu per satu */
.car-grid .car:nth-child(1),
.car-grid .car-card:nth-child(1) {
  animation-delay: 0.1s;
}
.car-grid .car:nth-child(2),
.car-grid .car-card:nth-child(2) {
  animation-delay: 0.2s;
}
.car-grid .car:nth-child(3),
.car-grid .car-card:nth-child(3) {
  animation-delay: 0.3s;
}
.car-grid .car:nth-child(4),
.car-grid .car-card:nth-child(4) {
  animation-delay: 0.4s;
}
.car-grid .car:nth-child(5),
.car-grid .car-card:nth-child(5) {
  animation-delay: 0.5s;
}
.car-grid .car:nth-child(6),
.car-grid .car-card:nth-child(6) {
  animation-delay: 0.6s;
}

/* gambar */
.car-card,
.car {
  transition: transform 0.5s cubic-bezier(0.23, 1, 0.32, 1),
              box-shadow 0.5s ease, 
              filter 0.3s ease;
  transform-style: preserve-3d;
  will-change: transform;
}

.car-card:hover,
.car:hover {
  transform: scale(1.07) rotateZ(-1deg);
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.25);
  filter: brightness(1.05) contrast(1.1);
}

    </style>
  </head>
  <body>
    <!-- Top bar -->
    <div class="top-bar">
      <div class="logo">
        <h5 class="m-0">Socar</h5>
      </div>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand" href="#">Welcome!</a>
        <button
          class="navbar-toggler text-white"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarContent"
        >
          ☰
        </button>
        <div class="collapse navbar-collapse" id="navbarContent">
          <ul class="navbar-nav me-auto ms-4">
            <li class="nav-item"><a class="nav-link" href="#">HOME</a></li>
            <li class="nav-item">
              <a class="nav-link" href="#">BERITA OTOMOTIF</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">KOMUNITAS</a>
            </li>
            <li class="nav-item"><a class="nav-link" href="#">FAQS</a></li>
            <li class="nav-item">
              <a class="nav-link" href="#">HUBUNGI KAMI</a>
            </li>
          </ul>

          <!-- User dropdown -->
          <div class="dropdown">
            <a
              class="btn btn-dark dropdown-toggle"
              href="#"
              role="button"
              data-bs-toggle="dropdown"
            >
              <?= $_SESSION['nama_user'] ?? 'Akun' ?>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="#">Profil</a></li>
              <li><a class="dropdown-item" href="logout.php">Logout</a></li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!-- car -->

         <section class="popular-cars">
      <p class="subtitle">New Popular Car</p>
      <h2 class="title">Shop Populer New Car</h2>
      <?php
// Ambil nama file saat ini, misalnya "chevrolet.php"
$current_page = basename($_SERVER['PHP_SELF']);

// Mapping file ke label
$brands = [
    'chevrolet.php'  => 'Chevrolet',
    'nissan.php'     => 'Nissan',
    'mitsubishi.php' => 'Mitsubishi',
    'tesla.php'      => 'Tesla',
    'jeep.php'       => 'Jeep',
    'mb.php'         => 'Mercedes Benz',
];
?>

<div class="filters">
  <!-- Tombol "Show All" aktif jika bukan di file brand -->
  <a href="pengguna.php" class="filter-btn <?= !array_key_exists($current_page, $brands) ? 'active' : '' ?>">Show All</a>

  <?php foreach ($brands as $file => $label): ?>
    <a href="<?= $file ?>" class="filter-btn <?= $current_page === $file ? 'active' : '' ?>">
      <?= $label ?>
    </a>
  <?php endforeach; ?>
</div>


      <div class="car-grid">
        <!-- Repeat this block for each car -->
        <div class="car-card">
          <img src="https://imgcdn.oto.com/large/gallery/exterior/133/2222/tesla-model-x-front-angle-low-view-481563.jpg" alt="Nissan GT-R" />
          <div class="car-info">
            <div class="car-header">
              <h3>Tesla</h3>
              <i class="fa-solid fa-heart heart"></i>
            </div>
            <p class="car-type">Sport</p>
            <p class="description">
              Tesla adalah pelopor kendaraan listrik dengan performa luar biasa dan teknologi autopilot canggih, mengantarkan masa depan mobilitas yang ramah lingkungan.
            </p>
            <div class="specs">
              <span>2023</span>
              <span>Manual</span>
              <span>2 People</span>
            </div>
            <div class="price-row">
              <span class="price">Rp 270,1 - 337,8 Juta</span>
              <span class="stars"><i class="fa-solid fa-star"></i>5</span>
              <button class="buy" onclick="window.location.href='ui_mobil/tesla.php'">Buy Now</button>
            </div>
          </div>
        </div>
        <!-- Tambahkan lebih banyak mobil dengan blok ini -->
    <!-- akhiran car -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
