<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Review Mobil</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="container py-4">

<h1 class="mb-4">Review & Rating Mobil</h1>
<p>Hai, <strong><?= $_SESSION['username'] ?></strong> | <a href="logout.php">Logout</a> | <a href="forum.php">Ke Forum</a></p>

<h3>Beri Review Mobil</h3>
<form method="POST" action="post_review.php" class="mb-4">
    <div class="mb-2">
        <input type="text" name="car_model" class="form-control" placeholder="Model Mobil" required>
    </div>
    <div class="mb-2">
        <select name="rating" class="form-select" required>
            <option value="">Pilih Rating</option>
            <?php for ($i=5; $i>=1; $i--): ?>
                <option value="<?= $i ?>"><?= $i ?> Bintang</option>
            <?php endfor; ?>
        </select>
    </div>
    <div class="mb-2">
        <textarea class="form-control" name="comment" placeholder="Tulis review Anda..." required></textarea>
    </div>
    <button class="btn btn-primary">Kirim Review</button>
</form>

<h4>Semua Review</h4>
<?php
$reviews = $conn->query("SELECT r.*, u.username FROM reviews r JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC");
while ($r = $reviews->fetch_assoc()):
?>
    <div class="card mb-2">
        <div class="card-body">
            <strong><?= $r['username'] ?></strong> menilai <strong><?= htmlspecialchars($r['car_model']) ?></strong>
            <p>Rating: <?= str_repeat("⭐", $r['rating']) ?></p>
            <p><?= nl2br(htmlspecialchars($r['comment'])) ?></p>
        </div>
    </div>
<?php endwhile; ?>
</body>
</html>
