<?php
session_start();
include 'db.php';

// Cek apakah user sudah login
$loggedIn = isset($_SESSION['user_id']);


// Ambil semua diskusi dengan nama user
$result = $conn->query("
    SELECT q.*, u.username as author_name 
    FROM questions q 
    LEFT JOIN users u ON q.user_id = u.id 
    ORDER BY q.created_at DESC  
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forum Diskusi Showroom Mobil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <!-- Header dengan info user -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">Forum Diskusi Showroom Mobil</h2>
        <div class="d-flex align-items-center">
            <span class="me-3">Selamat datang, <strong><?= $loggedIn ? htmlspecialchars($_SESSION['username']) : 'Tamu' ?></strong></span>
            <a href="../index.html" class="btn btn-outline-danger btn-sm">Kembali</a>
        </div>
    </div>

    <!-- Form Tambah Pertanyaan -->
    <div class="card mb-4">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <span>Buat Topik Baru</span>
                <small class="text-muted">Posting sebagai: <?= $loggedIn ? htmlspecialchars($_SESSION['username']) : 'Tamu' ?></small>
            </div>
        </div>
        <div class="card-body">
<form action="tambah.php" method="POST">
    <div class="mb-3">
        <input type="text" name="username" class="form-control" placeholder="Nama Anda" required>
    </div>
    <div class="mb-3">
        <input type="email" name="email" class="form-control" placeholder="Email Anda" required>
    </div>
    <div class="mb-3">
        <input type="text" name="title" class="form-control" placeholder="Judul Topik" required>
    </div>
    <div class="mb-3">
        <textarea name="content" class="form-control" rows="4" placeholder="Isi pertanyaan" required></textarea>
    </div>
    <button type="submit" class="btn btn-danger">Posting</button>
</form>
        </div>
    </div>

    <!-- Daftar Diskusi -->
    <div class="list-group">
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <a href="pertanyaan.php?id=<?= $row['id'] ?>" class="list-group-item list-group-item-action">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1"><?= htmlspecialchars($row['title']) ?></h5>
                        <small><?= $row['created_at'] ?></small>
                    </div>
                    <p class="mb-1"><?= nl2br(htmlspecialchars(substr($row['content'], 0, 100))) ?>...</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-muted">
                            Oleh: <strong><?= htmlspecialchars($row['author_name'] ?: 'User Tidak Dikenal') ?></strong>
                        </small>
                    </div>
                </a>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="alert alert-info">Belum ada topik diskusi. Jadilah yang pertama untuk memulai diskusi!</div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>