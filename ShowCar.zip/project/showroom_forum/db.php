<?php
$host = "localhost";
$user = "root";
$pass = ""; // jika pakai password, isi di sini
$dbname = "showcar_db"; // ubah ke nama baru

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
