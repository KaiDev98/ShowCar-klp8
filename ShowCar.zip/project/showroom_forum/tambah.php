<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);

    // Validasi sederhana
    if ($username && $email && $title && $content) {
        // Cek apakah user sudah ada berdasarkan email
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $user_id = $user['id'];
        } else {
            // Buat user baru
            $stmt = $conn->prepare("INSERT INTO users (username, email) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            $user_id = $stmt->insert_id;
        }

        // Simpan pertanyaan
        $stmt = $conn->prepare("INSERT INTO questions (user_id, title, content, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iss", $user_id, $title, $content);
        $stmt->execute();

        // Arahkan kembali ke halaman forum
        header("Location: index.php");
        exit();
    } else {
        echo "Semua field harus diisi.";
    }
}
?>
    