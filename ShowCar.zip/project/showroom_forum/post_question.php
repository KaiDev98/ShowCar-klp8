<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) exit;

$question = $_POST['question'];
$user_id = $_SESSION['user_id'];
$conn->query("INSERT INTO questions (user_id, question) VALUES ($user_id, '$question')");
header("Location: index.php");
