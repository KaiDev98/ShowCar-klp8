<?php
session_start();
include 'db.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$question_id = intval($_GET['id']);

// Ambil data pertanyaan
$q_stmt = $conn->prepare("
    SELECT q.*, u.username as author_name 
    FROM questions q 
    LEFT JOIN users u ON q.user_id = u.id 
    WHERE q.id = ?
");
$q_stmt->bind_param("i", $question_id);
$q_stmt->execute();
$question = $q_stmt->get_result()->fetch_assoc();

// Ambil daftar jawaban
$a_stmt = $conn->prepare("
    SELECT a.*, u.username, a.username AS guest_name, a.email 
    FROM answers a 
    LEFT JOIN users u ON a.user_id = u.id 
    WHERE a.question_id = ?
    ORDER BY a.created_at ASC
");
$a_stmt->bind_param("i", $question_id);
$a_stmt->execute();
$answers = $a_stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($question['title']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <a href="index.php" class="btn btn-secondary mb-4">← Kembali ke Forum</a>

    <!-- Pertanyaan -->
    <div class="card mb-4">
        <div class="card-header">
            <h4><?= htmlspecialchars($question['title']) ?></h4>
            <small>
                Ditanyakan oleh <strong><?= htmlspecialchars($question['author_name'] ?? 'Tamu') ?></strong> pada <?= $question['created_at'] ?>
            </small>
        </div>
        <div class="card-body">
            <p><?= nl2br(htmlspecialchars($question['content'])) ?></p>
        </div>
    </div>

    <!-- Jawaban -->
    <h5>Jawaban</h5>
    <?php if ($answers->num_rows > 0): ?>
        <?php while ($a = $answers->fetch_assoc()): ?>
            <div class="card mb-3">
                <div class="card-body">
                    <p><?= nl2br(htmlspecialchars($a['content'])) ?></p>
                    <small class="text-muted">
                        Dijawab oleh 
                        <strong><?= htmlspecialchars($a['username'] ?? $a['guest_name'] ?? 'Tamu') ?></strong>
                        <?php if (!empty($a['email'])): ?>
                            (<?= htmlspecialchars($a['email']) ?>)
                        <?php endif; ?>
                        pada <?= $a['created_at'] ?>
                    </small>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="alert alert-info">Belum ada jawaban. Jadilah yang pertama!</div>
    <?php endif; ?>

    <!-- Form Jawaban -->
    <div class="card mt-4">
        <div class="card-header">Beri Jawaban</div>
        <div class="card-body">
            <form action="jawab.php" method="POST">
                <input type="hidden" name="question_id" value="<?= $question_id ?>">
                <div class="mb-3">
                    <input type="text" name="username" class="form-control" placeholder="Nama Anda" required>
                </div>
                <div class="mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Email Anda" required>
                </div>
                <div class="mb-3">
                    <textarea name="content" class="form-control" rows="4" placeholder="Tulis jawaban Anda..." required></textarea>
                </div>
                <button type="submit" class="btn btn-danger">Kirim Jawaban</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
