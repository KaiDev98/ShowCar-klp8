<?php
include 'db.php';

if (!isset($_POST['question_id']) || !isset($_POST['username']) || !isset($_POST['email']) || !isset($_POST['content'])) {
    die("Data tidak lengkap.");
}

$question_id = intval($_POST['question_id']);
$username = trim($_POST['username']);
$email = trim($_POST['email']);
$content = trim($_POST['content']);

// Simpan ke database
$stmt = $conn->prepare("INSERT INTO answers (question_id, username, email, content) VALUES (?, ?, ?, ?)");
$stmt->bind_param("isss", $question_id, $username, $email, $content);
$stmt->execute();

header("Location: pertanyaan.php?id=" . $question_id);
exit();
