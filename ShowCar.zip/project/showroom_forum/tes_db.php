<?php
$host = "localhost";
$user = "root";
$pass = ""; // jika kamu pakai password, ganti di sini
$dbname = "showcar_db";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Koneksi Gagal: " . $conn->connect_error);
}
echo "✅ Koneksi Berhasil ke database showcar_db";
?>
