<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) exit;

$question_id = $_POST['question_id'];
$answer = $_POST['answer'];
$user_id = $_SESSION['user_id'];
$conn->query("INSERT INTO answers (question_id, user_id, answer) VALUES ($question_id, $user_id, '$answer')");
header("Location: index.php");
