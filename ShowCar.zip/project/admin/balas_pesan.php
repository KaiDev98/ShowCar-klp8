<?php
include 'koneksi.php';

if (!isset($_GET['id'])) {
  echo "ID pesan tidak ditemukan.";
  exit;
}

$id = intval($_GET['id']);
$query = "SELECT * FROM kontak WHERE id = $id";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) === 0) {
  echo "Pesan tidak ditemukan.";
  exit;
}

$data = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Balas Pesan</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body { font-family: Arial, sans-serif; padding: 30px; background-color: #f8f9fa; }
    .form-container { background-color: #fff; padding: 20px; border-radius: 8px; max-width: 600px; margin: auto; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
    h2 { margin-bottom: 20px; }
    label { display: block; margin-top: 10px; font-weight: bold; }
    textarea, input { width: 100%; padding: 10px; margin-top: 5px; border-radius: 4px; border: 1px solid #ccc; }
    button { margin-top: 15px; padding: 10px 20px; background-color: #343a40; color: #ffc107; border: none; border-radius: 4px; cursor: pointer; }
    button:hover { background-color: #212529; }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Balas Pesan dari <?= htmlspecialchars($data['nama']) ?></h2>
    <p><strong>Email:</strong> <?= htmlspecialchars($data['email']) ?></p>
    <p><strong>Pesan:</strong><br><?= nl2br(htmlspecialchars($data['pesan'])) ?></p>

    <form action="proses_balas.php" method="POST">
      <input type="hidden" name="email_tujuan" value="<?= htmlspecialchars($data['email']) ?>">
      <input type="hidden" name="nama_penerima" value="<?= htmlspecialchars($data['nama']) ?>">
      <label for="subjek">Subjek</label>
      <input type="text" name="subjek" id="subjek" required>

      <label for="isi">Isi Pesan</label>
      <textarea name="isi" id="isi" rows="6" required></textarea>

      <button type="submit">Kirim Balasan</button>
    </form>
  </div>
</body>
</html>
