<?php
include 'koneksi.php';
if (!isset($_GET['id'])) {
    header("Location: pelanggan.php");
    exit();
}

$id = $_GET['id'];
$data = $conn->query("SELECT * FROM pemesanan WHERE id = $id")->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $merk = $_POST['merk'];
    $model = $_POST['model'];
    $warna = $_POST['warna'];
    $conn->query("UPDATE pemesanan SET merk='$merk', model='$model', warna='$warna' WHERE id=$id");
    header("Location: pemesanan.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Pemesanan</title>
</head>
<body>
  <h2>Edit Pemesanan</h2>
  <form method="POST">
    Merk: <input type="text" name="merk" value="<?= $data['merk'] ?>"><br><br>
    Model: <input type="text" name="model" value="<?= $data['model'] ?>"><br><br>
    Warna: <input type="text" name="warna" value="<?= $data['warna'] ?>"><br><br>
    <input type="submit" value="Simpan Perubahan">
  </form>
</body>
</html>
