<?php
// koneksi
$host = "localhost";
$user = "root";
$pass = "";
$db = "showcar_db";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$reviews = $conn->query("
    SELECT r.*, m.nama_mobil 
    FROM review r 
    JOIN mobil m ON r.car_id = m.id_mobil 
    ORDER BY r.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Admin - Daftar Review Mobil</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<div class="container py-5">
  <h2 class="mb-4">📋 Daftar Review Pengguna</h2>

  <table class="table table-bordered">
    <thead class="table-light">
      <tr>
        <th>Nama User</th>
        <th>Mobil</th>
        <th>Rating</th>
        <th>Komentar</th>
        <th>Tanggal</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($r = $reviews->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($r['user_name']) ?></td>
          <td><?= htmlspecialchars($r['nama_mobil']) ?></td>
          <td><?= str_repeat('★', $r['rating']) ?></td>
          <td><?= htmlspecialchars($r['comment']) ?></td>
          <td><?= date('d M Y, H:i', strtotime($r['created_at'])) ?></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>
</body>
</html>
