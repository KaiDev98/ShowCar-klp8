<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $sql = "DELETE FROM mobil WHERE id = $id";

  if (mysqli_query($conn, $sql)) {
    header("Location: data_mobil.php");
    exit();
  } else {
    echo "Gagal menghapus data";
  }
}
?>
