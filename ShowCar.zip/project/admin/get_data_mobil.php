<?php
include 'koneksi.php';

$query = mysqli_query($conn, "
  SELECT mobil.*, kategori.nama_kategori, merek.nama_merek 
  FROM mobil 
  JOIN kategori ON mobil.id_kategori = kategori.id_kategori
  JOIN merek ON mobil.id_merek = merek.id_merek
");

$no = 1;
while ($row = mysqli_fetch_assoc($query)) {
    echo "<tr>
        <td>{$no}</td>
        <td>{$row['nama_mobil']}</td>
        <td>{$row['nama_merek']}</td>
        <td>{$row['nama_kategori']}</td>
        <td>{$row['stok']}</td>
        <td>Rp " . number_format($row['harga'], 0, ',', '.') . "</td>
        <td>
            <form method='POST' action='tambah_stok.php' style='display: flex; gap: 4px;'>
                <input type='hidden' name='id_mobil' value='{$row['id_mobil']}'>
                <input type='number' name='jumlah' min='1' style='width: 60px;' required>
                <button type='submit' style='background-color: #198754; color: white; border: none; padding: 4px 8px; border-radius: 4px;'>+</button>
            </form>
        </td>
    </tr>";
    $no++;
}
?>
