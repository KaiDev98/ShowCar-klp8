<?php
include 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ShowroomMobil Admin - Pesan Masuk</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    /* Sidebar dan konten seperti sebelumnya */

    body{
      font-family: "Segoe UI", sans-serif;
    }
    .sidebar {
      background-color: #212529;
      min-height: 100vh;
      padding-top: 20px;
      width: 220px;
      position: fixed;
      top: 0;
      left: 0;
    }

    .sidebar h2 {
      color: #ffc107;
      text-align: center;
      margin-bottom: 20px;
      font-weight: bold;
      font-size: 24px;
    }

    .sidebar ul {
      list-style: none;
      padding-left: 0;
    }

    .sidebar ul li a {
      color: #adb5bd;
      padding: 12px 20px;
      display: block;
      text-decoration: none;
      transition: background-color 0.3s ease;
      font-weight: 600;
    }

    .sidebar ul li a:hover,
    .sidebar ul li a.active {
      background-color: #343a40;
      color: #ffc107;
    }

    .main-content {
      margin-left: 220px;
      padding: 30px 40px;
      background-color: #f8f9fa;
      min-height: 100vh;
      font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
    }

    .main-content h1 {
      font-size: 2.2rem;
      margin-bottom: 10px;
      color: #343a40;
    }

    .main-content p {
      color: #6c757d;
      margin-bottom: 30px;
      font-size: 1rem;
    }

    .message-list {
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 2px 6px rgb(0 0 0 / 0.1);
      padding: 20px;
      max-width: 900px;
    }

    .message-item {
      border-bottom: 1px solid #dee2e6;
      padding: 15px 0;
      display: flex;
      flex-direction: column;
    }

    .message-item:last-child {
      border-bottom: none;
    }

    .message-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
    }

    .message-sender {
      font-weight: 700;
      color: #212529;
      font-size: 1.1rem;
    }

    .message-date {
      color: #6c757d;
      font-size: 0.85rem;
    }

    .message-content {
      color: #495057;
      font-size: 1rem;
      line-height: 1.4;
    }

    .message-actions {
      margin-top: 8px;
    }

    .message-actions button {
      background-color: #343a40;
      border: none;
      color: #ffc107;
      padding: 6px 12px;
      border-radius: 4px;
      cursor: pointer;
      font-weight: 600;
      transition: background-color 0.3s ease;
      margin-right: 10px;
    }

    .message-actions button:hover {
      background-color: #212529;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <h2>ShowroomMobil Admin</h2>
    <ul>
      <li><a href="index.php">Dashboard</a></li>
      <li><a href="data_mobil.php">Data Mobil</a></li>
      <li><a href="data_pengguna.php">Data Pengguna</a></li>
      <li><a href="kategori.php">Kategori</a></li>
      <li><a href="pembayaran.php">Pembayaran</a></li>
      <li><a href="pemesanan.php">Pemesanan</a></li>
      <li><a href="pesan_masuk.php" class="active">Pesan Masuk</a></li>
      <li><a href="data_pembelian.php">Data Pembelian</a></li>
    </ul>
  </div>

  <div class="main-content">
    <h1>Pesan Masuk</h1>
    <p>Daftar pesan yang dikirim oleh pengunjung atau pemesan.</p>

    <div class="message-list">
      <?php
      $query = "SELECT * FROM kontak ORDER BY tanggal DESC";
      $result = mysqli_query($conn, $query);

      if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
          echo '<div class="message-item">';
          echo '  <div class="message-header">';
          echo '    <div class="message-sender">' . htmlspecialchars($row['nama']) . '</div>';
          echo '    <div class="message-date">' . htmlspecialchars($row['tanggal']) . '</div>';
          echo '  </div>';
          echo '  <div class="message-content">' . nl2br(htmlspecialchars($row['pesan'])) . '</div>';
          echo '  <div class="message-actions">';
          echo '    <a href="balas_pesan.php?id=' . $row['id'] . '"><button>Balas</button></a>';
          echo '    <a href="hapus_pesan.php?id=' . $row['id'] . '" onclick="return confirm(\'Yakin ingin menghapus pesan ini?\')"><button>Hapus</button></a>';
          echo '  </div>';
          echo '</div>';
        }
      } else {
        echo '<p>Tidak ada pesan masuk.</p>';
      }
      ?>
    </div>
  </div>
</body>
</html>
