<?php
session_start();
if (!isset($_SESSION['admin_name'])) {
    header("Location: login.php");
    exit();
}
include 'koneksi.php';

// Ambil data kategori dan merek untuk dropdown
$kategori = mysqli_query($conn, "SELECT * FROM kategori");
$merek = mysqli_query($conn, "SELECT * FROM merek");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Tambah Mobil</title>
  <style>
    body {
      font-family: "Segoe UI", sans-serif;
      background-color: #f8f9fa;
      margin: 0;
      padding: 40px;
    }
    h1 {
      margin-bottom: 20px;
    }
    form {
      background-color: white;
      padding: 20px;
      max-width: 500px;
      border-radius: 8px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    input, select, button {
      width: 100%;
      margin-bottom: 15px;
      padding: 10px;
      border-radius: 4px;
      border: 1px solid #ced4da;
    }
    button {
      background-color: #343a40;
      color: white;
      border: none;
    }
  </style>
</head>
<body>
  <h1>Tambah Mobil Baru</h1>
  <form action="proses_tambah_mobil.php" method="POST">
    <input type="text" name="nama_mobil" placeholder="Nama Mobil" required>

    <label>Merek</label>
    <select name="id_merek" required>
      <option value="">-- Pilih Merek --</option>
      <?php while ($row = mysqli_fetch_assoc($merek)): ?>
        <option value="<?= $row['id_merek'] ?>"><?= $row['nama_merek'] ?></option>
      <?php endwhile; ?>
    </select>

    <label>Kategori</label>
    <select name="id_kategori" required>
      <option value="">-- Pilih Kategori --</option>
      <?php while ($row = mysqli_fetch_assoc($kategori)): ?>
        <option value="<?= $row['id_kategori'] ?>"><?= $row['nama_kategori'] ?></option>
      <?php endwhile; ?>
    </select>

    <input type="number" name="harga" placeholder="Harga" required>
    <input type="number" name="stok" placeholder="Stok" required>

    <label>Status</label>
    <select name="status" required>
      <option value="tersedia">Tersedia</option>
      <option value="terjual">Terjual</option>
    </select>

    <button type="submit">Simpan</button>
  </form>
</body>
</html>
