<?php
$conn = new mysqli("localhost", "root", "", "showcar_db");
$result = $conn->query("SELECT * FROM pembayaran");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Data Pengguna</title>
  <style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #999; padding: 8px; text-align: left; }
    th { background-color: #f44336; color: white; }
  </style>
</head>
<body>
  <h2>Data Pengguna</h2>
  <table>
    <tr>
      <th>No</th>
      <th>Nama</th>
      <th>Email</th>
      <th>Phone</th>
      <th>Tgl Lahir</th>
      <th>Gender</th>
      <th>Alamat</th>
      <th>Pertanyaan</th>
      <th>Created At</th>
    </tr>
    <?php $no = 1; while ($row = $result->fetch_assoc()) { ?>
    <tr>
      <td><?= $no++ ?></td>
      <td><?= htmlspecialchars($row['nama']) ?></td>
      <td><?= htmlspecialchars($row['email']) ?></td>
      <td><?= htmlspecialchars($row['phone']) ?></td>
      <td><?= htmlspecialchars($row['tgl_lahir']) ?></td>
      <td><?= htmlspecialchars($row['gender']) ?></td>
      <td><?= htmlspecialchars($row['alamat']) ?></td>
      <td><?= htmlspecialchars($row['pertanyaan']) ?></td>
      <td><?= htmlspecialchars($row['created_at']) ?></td>
    </tr>
    <?php } ?>
  </table>
</body>
</html>
