<?php
session_start();

// Simulasi data admin, biasanya dari database
$admin_username = "admin";
$admin_password = "admin123"; // Contoh password biasa, disarankan pakai hash di aplikasi nyata

// Ambil data dari form login
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Cek login
if ($username === $admin_username && $password === $admin_password) {
    // Jika cocok, simpan session admin_name
    $_SESSION['admin_name'] = $username;

    // Redirect ke index.php
    header("Location: index.php");
    exit();
} else {
    // Jika salah, kembali ke login dengan pesan error (bisa ditambah nanti)
    header("Location: login.php?error=invalid_credentials");
    exit();
}
?>
