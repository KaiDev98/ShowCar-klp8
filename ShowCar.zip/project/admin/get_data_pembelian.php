<?php
include 'koneksi.php';

$query = "SELECT * FROM pembelian ORDER BY created_at DESC";
$result = $conn->query($query);
$no = 1;

while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $no++ . "</td>";
    echo "<td>" . htmlspecialchars($row['nama_pembeli']) . "</td>";
    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
    echo "<td>" . htmlspecialchars($row['no_hp']) . "</td>";
    echo "<td>" . htmlspecialchars($row['alamat']) . "</td>";
    echo "<td>" . htmlspecialchars($row['warna']) . "</td>";

    echo "<td>
        <select onchange=\"updateStatus(" . $row['id'] . ", this.value)\">
            <option value='Belum Dibayar'" . ($row['status_pembayaran'] == 'Belum Dibayar' ? ' selected' : '') . ">Belum Dibayar</option>
            <option value='Dalam Proses'" . ($row['status_pembayaran'] == 'Dalam Proses' ? ' selected' : '') . ">Dalam Proses</option>
            <option value='Lunas'" . ($row['status_pembayaran'] == 'Lunas' ? ' selected' : '') . ">Lunas</option>
            <option value='Batal'" . ($row['status_pembayaran'] == 'Batal' ? ' selected' : '') . ">Batal</option>
        </select>
    </td>";

    echo "</tr>";
}
?>
