<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
  $id = intval($_GET['id']);
  $query = "DELETE FROM kontak WHERE id = $id";
  mysqli_query($conn, $query);
}

header("Location: pesan_masuk.php");
exit;
