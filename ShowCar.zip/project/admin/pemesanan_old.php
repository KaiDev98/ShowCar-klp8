<?php
$koneksi = new mysqli("localhost", "root", "", "showcar_db");
$result = $koneksi->query("SELECT * FROM pemesanan");
?>

<h2>Riwayat Pemesanan Mobil</h2>
<table border="1" cellpadding="10">
  <tr>
    <th>ID</th>
    <th>Code Nego</th>
    <th>Merk</th>
    <th>Model</th>
    <th>Warna</th>
    <th>Tanggal Pesan</th>
  </tr>
  <?php while($row = $result->fetch_assoc()): ?>
  <tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['code_nego'] ?></td>
    <td><?= $row['merk'] ?></td>
    <td><?= $row['model'] ?></td>
    <td><?= $row['warna'] ?></td>
    <td><?= $row['tanggal_pesan'] ?></td>
  </tr>
  <?php endwhile; ?>
</table>
