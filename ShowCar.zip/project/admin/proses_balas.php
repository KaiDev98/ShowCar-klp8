<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $to = $_POST['email_tujuan'];
  $nama = $_POST['nama_penerima'];
  $subject = $_POST['subjek'];
  $message = $_POST['isi'];

  $headers = "From: showroom@example.com\r\n";
  $headers .= "Reply-To: showroom@example.com\r\n";
  $headers .= "Content-type: text/plain; charset=UTF-8\r\n";

  $pesanLengkap = "Halo $nama,\n\n" . $message . "\n\nSalam,\nAdmin Showroom";

  if (mail($to, $subject, $pesanLengkap, $headers)) {
    echo "<script>alert('Balasan berhasil dikirim!'); window.location.href='pesan_masuk.php';</script>";
  } else {
    echo "<script>alert('Gagal mengirim balasan.'); history.back();</script>";
  }
} else {
  echo "Akses ditolak.";
}
