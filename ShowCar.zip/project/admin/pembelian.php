<?php
include 'koneksi.php';

$id_mobil = $_GET['id_mobil'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];
    $alamat = $_POST['alamat'];
    $warna = $_POST['warna'];

    $query = "INSERT INTO pembelian (nama_pembeli, email, no_hp, alamat, id_mobil, warna) 
              VALUES ('$nama', '$email', '$no_hp', '$alamat', '$id_mobil', '$warna')";
    mysqli_query($koneksi, $query);
    echo "<script>alert('Pemesanan berhasil!'); window.location='index.php';</script>";
}
?>

<form method="post" class="container mt-5">
  <h2>Form Pembelian Mobil</h2>
  <div class="form-group">
    <label>Nama Lengkap</label>
    <input type="text" name="nama" class="form-control" required>
  </div>
  <div class="form-group">
    <label>Email</label>
    <input type="email" name="email" class="form-control" required>
  </div>
  <div class="form-group">
    <label>No HP</label>
    <input type="text" name="no_hp" class="form-control" required>
  </div>
  <div class="form-group">
    <label>Alamat</label>
    <textarea name="alamat" class="form-control" required></textarea>
  </div>
  <div class="form-group">
    <label>Pilih Warna</label>
    <select name="warna" class="form-control">
      <option value="Hitam">Hitam</option>
      <option value="Merah">Merah</option>
      <option value="Putih">Putih</option>
      <option value="Silver">Silver</option>
      <option value="Kuning">Kuning</option>
    </select>
  </div>
  <button type="submit" class="btn btn-success">Kirim Pemesanan</button>
</form>
