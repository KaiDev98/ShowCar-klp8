<?php
session_start();
if (!isset($_SESSION['admin_name'])) {
    header("Location: login.php");
    exit();
}
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_mobil = mysqli_real_escape_string($conn, $_POST['nama_mobil']);
    $id_merek = intval($_POST['id_merek']);
    $id_kategori = intval($_POST['id_kategori']);
    $harga = intval($_POST['harga']);
    $stok = intval($_POST['stok']);
    $status = $_POST['status'];

    $query = "INSERT INTO mobil (nama_mobil, id_merek, id_kategori, harga, stok, status)
              VALUES ('$nama_mobil', $id_merek, $id_kategori, $harga, $stok, '$status')";

    if (mysqli_query($conn, $query)) {
        header("Location: data_mobil.php");
        exit();
    } else {
        echo "Gagal menambahkan mobil: " . mysqli_error($conn);
    }
} else {
    echo "Akses ditolak.";
}
?>
