<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>pembayaran | ShowroomMobil Admin</title>
  <link rel="stylesheet" href="style.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    .sidebar {
      background-color: #212529;
      min-height: 100vh;
      padding-top: 20px;
      width: 220px;
      position: fixed;
      top: 0;
      left: 0;
    }
    .sidebar h2 {
      color: #ffc107;
      text-align: center;
      margin-bottom: 20px;
      font-weight: bold;
      font-size: 24px;
    }
    .sidebar ul {
      list-style: none;
      padding-left: 0;
    }
    .sidebar ul li a {
      color: #adb5bd;
      padding: 12px 20px;
      display: block;
      text-decoration: none;
      transition: background-color 0.3s ease;
      font-weight: 600;
    }
    .sidebar ul li a:hover,
    .sidebar ul li a.active {
      background-color: #343a40;
      color: #ffc107;
    }
    .main-content {
      margin-left: 220px;
      padding: 30px 40px;
      background-color: #f8f9fa;
      min-height: 100vh;
    }
    .main-content h1 {
      font-size: 2.2rem;
      margin-bottom: 10px;
      color: #343a40;
    }
    .main-content p {
      color: #6c757d;
      margin-bottom: 30px;
      font-size: 1rem;
    }
    .btn-sm {
      font-size: 0.85rem;
      padding: 0.35rem 0.6rem;
      border-radius: 4px;
    }
    .btn-warning:hover {
      background-color: #e0a800;
      color: #fff;
    }
    .btn-danger:hover {
      background-color: #c82333;
      color: #fff;
    }
    .table-responsive {
      box-shadow: 0 2px 6px rgb(0 0 0 / 0.1);
      border-radius: 8px;
      background-color: #fff;
      padding: 15px;
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <h2>ShowroomMobil Admin</h2>
    <ul>
      <li><a href="index.php">Dashboard</a></li>
      <li><a href="data_mobil.php">Data Mobil</a></li>
      <li><a href="data_pengguna.php">Data Pengguna</a></li>
      <li><a href="kategori.php">Kategori</a></li>
      <li><a href="pembayaran.php" class="active">pembayaran</a></li>
      <li><a href="pemesanan.php">Pemesanan</a></li>
      <li><a href="pesan_masuk.php">Pesan Masuk</a></li>
      <li><a href="data_pembelian.php">Data Pembelian</a></li>
    </ul>
  </div>

  <!-- Main Content -->
  <div class="main-content container mt-4">
    <h1>Data Pembayaran</h1>
    <p>Menampilkan data pelanggan yang mengisi form pembayaran.</p>

    <a href="tambah_pembayaran.html" class="btn btn-primary mb-3">
      <i class="fa fa-plus"></i> Tambah pembayaran Baru
    </a>

    <div class="table-responsive">
      <table class="table table-striped table-bordered">
        <thead class="thead-dark">
          <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Tanggal Lahir</th>
            <th>Gender</th>
            <th>Alamat</th>
            <th>Pertanyaan</th>
            <th>Waktu Daftar</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
            include 'koneksi.php';
            $query = "SELECT * FROM pembayaran ORDER BY id ASC";
            $result = mysqli_query($conn, $query);
            $no = 1;

            while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>";
              echo "<td>{$no}</td>";
              echo "<td>" . htmlspecialchars($row['nama']) . "</td>";
              echo "<td>" . htmlspecialchars($row['email']) . "</td>";
              echo "<td>" . htmlspecialchars($row['phone']) . "</td>";
              echo "<td>" . $row['tgl_lahir'] . "</td>";
              echo "<td>" . $row['gender'] . "</td>";
              echo "<td>" . $row['alamat'] . "</td>";
              echo "<td>" . $row['pertanyaan'] . "</td>";
              echo "<td>" . $row['created_at'] . "</td>";
              echo "<td>
                      <a href='edit.php?id={$row['id']}' class='btn btn-sm btn-warning'>Edit</a>
                      <a href='hapus.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick=\"return confirm('Yakin ingin menghapus?')\">Hapus</a>
                    </td>";
              echo "</tr>";
              $no++;
            }
          ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
