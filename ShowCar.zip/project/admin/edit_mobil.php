<?php
include 'koneksi.php';
$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM mobil WHERE id_mobil = '$id'");
$m = mysqli_fetch_assoc($data);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nama_mobil = $_POST['nama_mobil'];
  $id_merek = $_POST['id_merek'];
  $id_kategori = $_POST['id_kategori'];
  $stok = $_POST['stok'];
  $harga = $_POST['harga'];

  $query = "UPDATE mobil SET 
              nama_mobil = '$nama_mobil',
              id_merek = '$id_merek',
              id_kategori = '$id_kategori',
              stok = '$stok',
              harga = '$harga'
            WHERE id_mobil = '$id'";

  if (mysqli_query($conn, $query)) {
    header("Location: data_mobil.php");
    exit();
  } else {
    echo "Gagal mengedit data: " . mysqli_error($conn);
  }
}
?>

<form method="POST">
  <label>Nama Mobil</label><br>
  <input type="text" name="nama_mobil" value="<?= $m['nama_mobil'] ?>" required><br>

  <label>Merek</label><br>
  <select name="id_merek">
    <?php
    $merek = mysqli_query($conn, "SELECT * FROM merek");
    while ($mr = mysqli_fetch_assoc($merek)) {
      $selected = $mr['id_merek'] == $m['id_merek'] ? 'selected' : '';
      echo "<option value='{$mr['id_merek']}' $selected>{$mr['nama_merek']}</option>";
    }
    ?>
  </select><br>

  <label>Kategori</label><br>
  <select name="id_kategori">
    <?php
    $kategori = mysqli_query($conn, "SELECT * FROM kategori");
    while ($kt = mysqli_fetch_assoc($kategori)) {
      $selected = $kt['id_kategori'] == $m['id_kategori'] ? 'selected' : '';
      echo "<option value='{$kt['id_kategori']}' $selected>{$kt['nama_kategori']}</option>";
    }
    ?>
  </select><br>

  <label>Stok</label><br>
  <input type="number" name="stok" value="<?= $m['stok'] ?>" required><br>

  <label>Harga</label><br>
  <input type="number" name="harga" value="<?= $m['harga'] ?>" required><br><br>

  <button type="submit">Update</button>
</form>
