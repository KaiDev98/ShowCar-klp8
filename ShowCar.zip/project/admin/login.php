<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <title>Login Admin</title>
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
    />
    <style>
      body {
        background-color: #f8f9fa;
      }
      .login-container {
        margin-top: 100px;
      }
      .card {
        padding: 30px;
        border-radius: 15px;
      }
    </style>
  </head>
  <body>
    <div class="container login-container">
      <div class="row justify-content-center">
        <div class="col-md-5">
          <div class="card shadow">
            <h3 class="text-center mb-4">Login Admin</h3>
            <form action="proses_login.php" method="POST">
              <div class="form-group">
                <label for="username">Username</label>
                <input
                  type="text"
                  class="form-control"
                  name="username"
                  id="username"
                  required
                />
              </div>

              <div class="form-group">
                <label for="password">Password</label>
                <input
                  type="password"
                  class="form-control"
                  name="password"
                  id="password"
                  required
                />
              </div>

              <button type="submit" class="btn btn-primary btn-block">
                Login
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
