<?php
session_start();
if (!isset($_SESSION['admin_name'])) {
    header("Location: login.php");
    exit();
}
include 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Data Mobil</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    body {
      margin: 0;
      font-family: "Segoe UI", sans-serif;
      background-color: #f1f3f5;
      color: #212529;
      display: flex;
    }

    .sidebar {
      background-color: #212529;
      color: white;
      width: 220px;
      height: 100vh;
      padding: 20px 0;
      position: fixed;
    }

    .sidebar h2 {
      text-align: center;
      font-size: 20px;
      margin-bottom: 30px;
      color: #ffc107;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
    }

    .sidebar ul li a {
      color: #adb5bd;
      text-decoration: none;
      padding: 10px 20px;
      display: block;
      transition: 0.3s;
    }

    .sidebar ul li a:hover,
    .sidebar ul li a.active {
      background-color: #343a40;
      color: #fff;
      border-left: 4px solid #ffc107;
    }

    .main {
      margin-left: 240px;
      padding: 40px;
      flex: 1;
    }

    h1 {
      font-size: 28px;
      font-weight: bold;
      margin-bottom: 10px;
    }

    p {
      font-size: 16px;
      color: #495057;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      background-color: white;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
      overflow: hidden;
    }

    table th, table td {
      padding: 12px 15px;
      border-bottom: 1px solid #dee2e6;
    }

    table th {
      background-color: #343a40;
      color: white;
      text-align: left;
    }

    table tr:hover {
      background-color: #f8f9fa;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <h2>ShowroomMobil Admin</h2>
    <ul>
      <li><a href="index.php">Dashboard</a></li>
      <li><a href="data_mobil.php" class="active">Data Mobil</a></li>
      <li><a href="data_pengguna.php">Data Pengguna</a></li>
      <li><a href="kategori.php">Kategori</a></li>
      <li><a href="pemmbayaran.php">Pembayaran</a></li>
      <li><a href="pemesanan.php">Pemesanan</a></li>
      <li><a href="pesan_masuk.php">Pesan Masuk</a></li>
      <li><a href="data_pembelian.php">Data Pembelian</a></li>
    </ul>
  </div>

  <div class="main">
    <h1>Data Mobil</h1>
    <p>Daftar mobil tersedia dan stok menipis.</p>
    <p>
      <a href="tambah_mobil.php" style="padding: 8px 16px; background-color: #343a40; color: white; border-radius: 4px; text-decoration: none;">+ Tambah Mobil</a>
    </p>

    <table>
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Mobil</th>
          <th>Merek</th>
          <th>Kategori</th>
          <th>Stok</th>
          <th>Harga</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody id="mobilTableBody">
        <!-- Data akan dimuat oleh JavaScript -->
      </tbody>
    </table>
  </div>

  <script>
    function loadMobilData() {
      const xhr = new XMLHttpRequest();
      xhr.open("GET", "get_data_mobil.php", true);
      xhr.onload = function () {
        if (xhr.status === 200) {
          document.getElementById("mobilTableBody").innerHTML = xhr.responseText;
        }
      };
      xhr.send();
    }

    // Load data awal dan refresh tiap 10 detik
    loadMobilData();
    setInterval(loadMobilData, 10000);
  </script>
</body>
</html>
