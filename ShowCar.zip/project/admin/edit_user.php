<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $query = mysqli_query($conn, "SELECT * FROM users WHERE id = $id");
  $user = mysqli_fetch_assoc($query);

  if (!$user) {
    echo "User tidak ditemukan.";
    exit;
  }
}

if (isset($_POST['submit'])) {
  $username = $_POST['username'];
  $phone = $_POST['phone'];

  $update = mysqli_query($conn, "UPDATE users SET username='$username', phone='$phone' WHERE id = $id");

  if ($update) {
    echo "<script>alert('Data berhasil diupdate!'); window.location.href='data_pengguna.php';</script>";
  } else {
    echo "Gagal mengupdate data: " . mysqli_error($conn);
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Edit Pengguna</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="p-5">
  <div class="container">
    <h2><i class="bi bi-pencil-square"></i> Edit Pengguna</h2>
    <form method="POST" class="mt-4">
      <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Nomor Telepon</label>
        <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone']) ?>" required>
      </div>

      <button type="submit" name="submit" class="btn btn-primary">
        <i class="bi bi-save"></i> Simpan Perubahan
      </button>
      <a href="data_pengguna.php" class="btn btn-secondary ms-2">
        <i class="bi bi-arrow-left-circle"></i> Kembali
      </a>
    </form>
  </div>
</body>
</html>
