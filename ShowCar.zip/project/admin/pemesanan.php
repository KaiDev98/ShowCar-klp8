<?php
session_start();
if (!isset($_SESSION['admin_name'])) {
    header("Location: login.php");
    exit();
}

$koneksi = new mysqli("localhost", "root", "", "showcar_db");
$result = $koneksi->query("SELECT * FROM pemesanan");

include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ShowroomMobil Admin - Pemesanan</title>
  <link rel="stylesheet" href="style.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    /* Gaya seperti sebelumnya */
    body {
      margin: 0;
      font-family: "Segoe UI", sans-serif;
      background-color: #f1f3f5;
      color: #212529;
      display: flex;
    }

    .sidebar {
      background-color: #212529;
      color: white;
      width: 220px;
      height: 100vh;
      padding: 20px 0;
      position: fixed;
    }

    .sidebar h2 {
      text-align: center;
      font-size: 20px;
      margin-bottom: 30px;
      color: #ffc107;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
    }

    .sidebar ul li a {
      color: #adb5bd;
      text-decoration: none;
      padding: 10px 20px;
      display: block;
      transition: 0.3s;
    }

    .sidebar ul li a:hover,
    .sidebar ul li a.active {
      background-color: #343a40;
      color: #fff;
      border-left: 4px solid #ffc107;
    }

    .main-content {
      margin-left: 240px;
      padding: 40px;
      flex: 1;
    }

    h1 {
      font-size: 28px;
      font-weight: bold;
      margin-bottom: 10px;
    }

    p {
      font-size: 16px;
      color: #495057;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      background-color: white;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
      overflow: hidden;
    }

    table th, table td {
      padding: 12px 15px;
      border-bottom: 1px solid #dee2e6;
      text-align: left;
    }

    table th {
      background-color: #343a40;
      color: white;
    }

    table tr:hover {
      background-color: #f8f9fa;
    }

    .btn-add {
      display: inline-block;
      margin-bottom: 20px;
      background-color: #28a745;
      color: white;
      padding: 10px 20px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 600;
      transition: background-color 0.3s ease;
    }

    .btn-add:hover {
      background-color: #218838;
      color: white;
    }

    .action-link {
      color: #007bff;
      text-decoration: none;
      margin-right: 10px;
    }

    .action-link:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <h2>ShowroomMobil Admin</h2>
    <ul>
      <li><a href="index.php">Dashboard</a></li>
      <li><a href="data_mobil.php">Data Mobil</a></li>
      <li><a href="data_pengguna.php">Data Pengguna</a></li>
      <li><a href="kategori.php">Kategori</a></li>
      <li><a href="pembayaran.php">Pembayaran</a></li>
      <li><a href="pemesanan.php" class="active">Pemesanan</a></li>
      <li><a href="pesan_masuk.php">Pesan Masuk</a></li>
      <li><a href="data_pembelian.php">Data Pembelian</a></li>
    </ul>
  </div>
  <!-- Bagian Riwayat Pemesanan -->
<?php
  $result_pesan = $conn->query("SELECT * FROM pemesanan");
?>
<div class="main-content">
  <h1>Riwayat Pemesanan Mobil</h1>

  <div class="table-responsive">
    <table class="table table-striped table-bordered">
      <thead class="thead-dark">
        <tr>
          <th>ID</th>
          <th>Code Nego</th>
          <th>Merk</th>
          <th>Model</th>
          <th>Warna</th>
          <th>Tanggal Pesan</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $result_pesan = $conn->query("SELECT * FROM pemesanan");
        while($row = $result_pesan->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['code_nego']) ?></td>
            <td><?= htmlspecialchars($row['merk']) ?></td>
            <td><?= htmlspecialchars($row['model']) ?></td>
            <td><?= htmlspecialchars($row['warna']) ?></td>
            <td><?= htmlspecialchars($row['tanggal_pesan']) ?></td>
            <td>
              <a href="edit_pemesanan.php?id=<?= $row['id'] ?>" class="action-link text-warning me-2">
                <i class="bi bi-pencil-square"></i>
              </a>
              <a href="hapus_pemesanan.php?id=<?= $row['id'] ?>" class="action-link text-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">
                <i class="bi bi-trash-fill"></i>
              </a>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>


</body>
</html>
