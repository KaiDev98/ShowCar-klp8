<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $conn->query("DELETE FROM pemesanan WHERE id = $id");
}

header("Location: pemesanan.php");
exit();
?>
