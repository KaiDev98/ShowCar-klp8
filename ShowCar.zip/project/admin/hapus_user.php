<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $hapus = mysqli_query($conn, "DELETE FROM users WHERE id = $id");

  if ($hapus) {
    echo "<script>alert('🗑️ Data berhasil dihapus!'); window.location.href='data_pengguna.php';</script>";
  } else {
    echo "<script>alert('Gagal menghapus data.'); window.location.href='data_pengguna.php';</script>";
  }
} else {
  echo "<script>alert('ID tidak ditemukan.'); window.location.href='data_pengguna.php';</script>";
}
?>
