<?php
$host = "localhost";      // atau gunakan "127.0.0.1"
$user = "root";           // default user XAMPP
$pass = "";               // biasanya kosong di XAMPP
$db   = "showcar_db";     // nama database kamu

// Membuat koneksi
$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
