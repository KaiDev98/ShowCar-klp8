<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>BMW X3 DRIVE 201</title>
    <style>
      body {
        background-color: #fff;
        margin: 0;
        font-family: Arial, sans-serif;
      }
      .container {
        max-width: 900px;
        margin: 40px auto;
        background: white;
        padding: 20px;
        box-sizing: border-box;
        min-height: 600px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      }
      .content {
        display: flex;
        gap: 30px;
        flex-wrap: wrap;
      }
      .left,
      .right {
        flex: 1 1 400px;
      }
      .left h2 {
        font-weight: 600;
        font-size: 18px;
        margin-bottom: 15px;
        padding-left: 15px;
      }
      .left img {
        width: 100%;
        border-radius: 10px;
        object-fit: cover;
      }
      .right h3 {
        margin: 0 0 15px 0;
        font-weight: 600;
        font-size: 18px;
      }
      .nego-form {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-bottom: 20px;
      }
      .nego-form input[type="text"],
      .nego-form select {
        padding: 8px 12px;
        font-size: 14px;
        border-radius: 8px;
        border: 1px solid #ccc;
      }
      .nego-form button {
        background: red;
        color: white;
        border: none;
        padding: 10px;
        font-weight: 600;
        border-radius: 8px;
        cursor: pointer;
        align-self: flex-start;
      }
      .info {
        font-size: 14px;
      }
      .info b {
        display: inline-block;
        width: 60px;
      }
      .footer {
        background: red;
        padding: 12px 20px;
        margin-top: 30px;
        text-align: center;
      }
      .footer span {
        background: black;
        color: white;
        padding: 6px 12px;
        font-size: 12px;
        font-weight: 600;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="content">
        <div class="left">
          <h2>BMX X3 DRIVE 201 CKD A/T 2021</h2>
          <img
            src="https://images.unsplash.com/photo-1704340142770-b52988e5b6eb?q=80&w=2000&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            alt="BMW Car"
          />
        </div>
        <div class="right">
          <h3>RP.356.000.000</h3>
          <form class="nego-form" action="pembayaran.php" method="POST">
            <input
              type="text"
              name="code_nego"
              placeholder="Code Nego (Opsional)"
            />

            <select name="merk" required>
              <option value="">Pilih Merk</option>
              <option value="BMW">BMW</option>
              <option value="Toyota">Toyota</option>
              <option value="Honda">Honda</option>
            </select>

            <select name="model" required>
              <option value="">Pilih Model</option>
              <option value="X3">X3</option>
              <option value="X5">X5</option>
              <option value="Civic">Civic</option>
            </select>

            <select name="warna" required>
              <option value="">Pilih Warna</option>
              <option value="Hitam">Hitam</option>
              <option value="Putih">Putih</option>
              <option value="Silver">Silver</option>
            </select>

            <button type="submit">Submit ➔</button>
          </form>

          <div class="info">
            <p><b>Informasi Kendaraan</b></p>
            <p><b>Merk</b> Model</p>
            <p>BMW &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -</p>
            <p><b>Hubungi Kami :</b> 07280527976</p>
          </div>
        </div>
      </div>
      <div class="footer">
        <span>Dibuat oleh Kelompok 8 menggunakan css dan js</span>
      </div>
    </div>
  </body>
</html>
