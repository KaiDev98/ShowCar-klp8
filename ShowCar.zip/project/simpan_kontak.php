<?php
$koneksi = new mysqli("localhost", "root", "", "showcar_db");

if ($koneksi->connect_error) {
  die("Koneksi gagal: " . $koneksi->connect_error);
}

$nama = $_POST['name'];
$email = $_POST['email'];
$pesan = $_POST['pesan'];

$sql = "INSERT INTO kontak (nama, email, pesan) VALUES ('$nama', '$email', '$pesan')";

if ($koneksi->query($sql) === TRUE) {
  echo "<script>
          alert('Pesan berhasil dikirim!');
          window.location.href = 'index.html';
        </script>";
} else {
  echo "<script>
          alert('Gagal mengirim pesan: " . addslashes($koneksi->error) . "');
          window.history.back();
        </script>";
}

$koneksi->close();
?>
