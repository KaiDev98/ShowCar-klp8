<?php
// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Koneksi ke database
include 'koneksi.php';

// Ambil data dari form
$code_nego = $_POST['code_nego'] ?? '';
$merk = $_POST['merk'] ?? '';
$model = $_POST['model'] ?? '';
$warna = $_POST['warna'] ?? '';

// Validasi sederhana
if ($merk && $model && $warna) {
    $query = "INSERT INTO pemesanan (code_nego, merk, model, warna) 
              VALUES ('$code_nego', '$merk', '$model', '$warna')";

    if (mysqli_query($conn, $query)) {
        echo "✅ Data berhasil disimpan.";
        // Redirect ke halaman sukses
        header("Location: ../pembayaran.php?status=sukses");
        exit;
    } else {
        echo "❌ Gagal menyimpan data: " . mysqli_error($conn);
    }
} else {
    echo "❌ Data tidak lengkap.";
}
?>
