<?php
$host = "localhost";
$user = "root";
$pass = ""; // sesuaikan dengan password MySQL kamu
$db = "showcar_db";

// Koneksi ke database
$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari form
$code_nego = $_POST['code_nego'] ?? '';
$merk = $_POST['merk'];
$model = $_POST['model'];
$warna = $_POST['warna'];

// Simpan ke tabel pemesanan
$sql = "INSERT INTO pemesanan (code_nego, merk, model, warna) 
        VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $code_nego, $merk, $model, $warna);

if ($stmt->execute()) {
    echo "Pemesanan berhasil disimpan!";
    // redirect ke halaman sukses atau daftar pesanan jika perlu
    // header("Location: pembayaran.php");
} else {
    echo "Gagal menyimpan: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
