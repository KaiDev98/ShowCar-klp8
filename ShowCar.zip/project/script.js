document.addEventListener("DOMContentLoaded", function () {
  const buttons = document.querySelectorAll(".filter-buttons button");
  const cars = document.querySelectorAll(".car");

  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      const filter = button.textContent.toLowerCase();
      cars.forEach((car) => {
        const carName = car.querySelector("h3").textContent.toLowerCase();
        if (filter === "show all" || carName.includes(filter)) {
          car.style.display = "block";
        } else {
          car.style.display = "none";
        }
      });
    });
  });
});

document.querySelectorAll(".faq-item").forEach((item) => {
  item.querySelector(".faq-question").addEventListener("click", () => {
    document.querySelectorAll(".faq-item").forEach((el) => {
      if (el !== item) el.classList.remove("active");
    });
    item.classList.toggle("active");
  });
});
