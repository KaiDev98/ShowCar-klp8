<?php
$conn = new mysqli("localhost", "root", "", "showcar_db");

$username = $_POST['username'];
$car_id = $_POST['car_id'];
$rating = $_POST['rating'];
$comment = $_POST['comment'];

$stmt = $conn->prepare("INSERT INTO review (user_name, car_id, rating, comment) VALUES (?, ?, ?, ?)");
$stmt->bind_param("siis", $username, $car_id, $rating, $comment);

if ($stmt->execute()) {
    header("Location: review.php?success=1");
} else {
    echo "Gagal menyimpan review: " . $stmt->error;
}
?>
