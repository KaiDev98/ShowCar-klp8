<?php
session_start(); // Wajib untuk menggunakan session

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "showcar_db");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari form login
$username = $_POST['username'];
$password = $_POST['password'];

// Query cari user berdasarkan username
$sql = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

// Cek apakah user ditemukan
if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    // Verifikasi password yang dimasukkan dengan yang di database
    if (password_verify($password, $user['password'])) {
        // Simpan data ke session
        $_SESSION['id_user'] = $user['id']; // opsional
        $_SESSION['username'] = $user['username'];
        $_SESSION['nama_user'] = $user['username']; // Menggunakan username sebagai nama_user

        // Redirect ke halaman pengguna
        header("Location: pengguna.php");
        exit(); // Sangat penting agar tidak ada kode lain yang dijalankan
    } else {
        echo "<script>alert('Password salah!'); window.location='login.php';</script>";
    }
} else {
    echo "<script>alert('Username tidak ditemukan!'); window.location='login.php';</script>";
}

// Tutup koneksi
$conn->close();
?>
