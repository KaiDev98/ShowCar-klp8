<?php
include 'koneksi.php';

// Cek apakah parameter id tersedia
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  echo "ID berita tidak valid!";
  exit;
}

$id = (int) $_GET['id']; // pastikan hanya angka

// Ambil data dari database
$query = mysqli_query($conn, "SELECT * FROM berita WHERE id = $id");
$data = mysqli_fetch_assoc($query);

// Cek apakah data ditemukan
if (!$data) {
  echo "Berita tidak ditemukan!";
  exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title><?= htmlspecialchars($data['judul']); ?></title>
  <link rel="stylesheet" href="assets/css/berita-detail.css">
</head>
<body>
  <div class="article-container">
    <h1><?= htmlspecialchars($data['judul']); ?></h1>
    <div class="article-meta"><?= $data['tanggal_publikasi']; ?> | oleh <?= htmlspecialchars($data['penulis']); ?></div>
    <img src="uploads/<?= htmlspecialchars($data['gambar']); ?>" alt="<?= htmlspecialchars($data['judul']); ?>">
    <p><?= nl2br(htmlspecialchars($data['isi'])); ?></p>
    <a class="back-link" href="berita-otomotif.php">← Kembali ke berita</a>
  </div>
</body>
</html>
