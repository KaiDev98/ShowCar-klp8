<?php
$host = "localhost";     // Ganti jika database di server lain
$user = "root";          // Username database (default XAMPP = root)
$pass = "";              // Password database (default XAMPP = kosong)
$db   = "showroom"; // Nama database yang kamu buat

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
