<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Booking Test Drive</title>
  <link rel="stylesheet" href="assets/css/b-style.css">
</head>
<body>
  <div class="container">
    <header>
      <h1>📋 Booking Test Drive</h1>
    </header>

    <?php if (isset($_GET['success'])): ?>
      <div class="notif success">✅ Terima kasih! Booking Anda telah diterima.</div>
    <?php endif; ?>

    <form method="post" action="booking.php">
      <h2>Informasi Pribadi</h2>

      <label for="nama_lengkap">Nama Lengkap*</label>
      <input id="nama_lengkap" name="nama_lengkap" required>

      <label for="email">Email*</label>
      <input id="email" name="email" type="email" required>

      <label for="no_hp">No. Handphone*</label>
      <input id="no_hp" name="no_hp" type="text" required>

      <label for="tanggal_lahir">Tanggal Lahir*</label>
      <input id="tanggal_lahir" name="tanggal_lahir" type="date" required>

      <label for="gender">Gender*</label>
      <select id="gender" name="gender" required>
        <option value="">-- Pilih --</option>
        <option value="Laki-laki">Laki-laki</option>
        <option value="Perempuan">Perempuan</option>
      </select>

      <label for="alamat">Alamat*</label>
      <textarea id="alamat" name="alamat" rows="2" required></textarea>

      <h2>Detail Booking</h2>

      <label for="kota">Kota*</label>
      <input id="kota" name="kota" required>

      <label for="merk_mobil">Merk Mobil*</label>
      <input id="merk_mobil" name="merk_mobil" required>

      <label for="waktu_testdrive">Waktu Test Drive*</label>
      <input id="waktu_testdrive" name="waktu_testdrive" type="datetime-local" required>

      <label for="pertanyaan">Pertanyaan</label>
      <textarea id="pertanyaan" name="pertanyaan" rows="3"></textarea>

      <div class="checkbox-group full">
        <input type="checkbox" id="agree" name="agree" required>
        <label for="agree">Saya setuju dengan <a href="#">Kebijakan Privasi</a>.</label>
      </div>

      <div class="btn-group">
        <button type="submit" name="submit">Kirim</button>
        <button type="reset">Reset</button>
      </div>
    </form>
  </div>

  <?php if (isset($_GET['success'])): ?>
  <script>
    alert("Terima kasih! Booking test drive Anda telah berhasil dikirim.");
  </script>
  <?php endif; ?>
</body>
</html>
