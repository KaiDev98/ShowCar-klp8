<?php
session_start(); // WAJIB ADA sebelum apapun

include '../koneksi.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Data Pengguna</title>
  <link rel="stylesheet" href="style.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    /* Style seperti sebelumnya */
    body {
      margin: 0;
      font-family: "Segoe UI", sans-serif;
      background-color: #f1f3f5;
      color: #212529;
      display: flex;
    }
    .sidebar {
      background-color: #212529;
      color: white;
      width: 220px;
      height: 100vh;
      padding: 20px 0;
      position: fixed;
    }
    .sidebar h2 {
      text-align: center;
      font-size: 20px;
      margin-bottom: 30px;
      color: #ffc107;
    }
    .sidebar ul {
      list-style: none;
      padding: 0;
    }
    .sidebar ul li a {
      color: #adb5bd;
      text-decoration: none;
      padding: 10px 20px;
      display: block;
      transition: 0.3s;
    }
    .sidebar ul li a:hover,
    .sidebar ul li a.active {
      background-color: #343a40;
      color: #fff;
      border-left: 4px solid #ffc107;
    }
    .main {
      margin-left: 240px;
      padding: 40px;
      flex: 1;
    }
    h1 {
      font-size: 28px;
      font-weight: bold;
      margin-bottom: 10px;
    }
    p {
      font-size: 16px;
      color: #495057;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      background-color: white;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
      overflow: hidden;
    }
    table th,
    table td {
      padding: 12px 15px;
      border-bottom: 1px solid #dee2e6;
    }
    table th {
      background-color: #343a40;
      color: white;
      text-align: left;
    }
    table tr:hover {
      background-color: #f8f9fa;
    }
    .btn-add {
      display: inline-block;
      margin-bottom: 20px;
      background-color: #ffc107;
      color: #212529;
      padding: 10px 20px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 600;
      transition: background-color 0.3s ease;
    }
    .btn-add:hover {
      background-color: #e0a800;
      color: #fff;
    }
    .navbar-text {
      font-size: 16px;
      margin-bottom: 20px;
      color: #343a40;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <h2>ShowroomMobil Admin</h2>
    <ul>
      <li><a href="index.php">Dashboard</a></li>
      <li><a href="data_mobil.php">Data Mobil</a></li>
      <li><a href="data_pengguna.php" class="active">Data Pengguna</a></li>
      <li><a href="kategori.php">Kategori</a></li>
      <li><a href="pembayaran.php">pembayaran</a></li>
      <li><a href="pemesanan.php">Pemesanan</a></li>
      <li><a href="pesan_masuk.php">Pesan Masuk</a></li>
      <li><a href="data_pembelian.php">Data Pembelian</a></li>
    </ul>
  </div>

  <div class="main">
    <div class="navbar-text">
      Halo, <?= isset($_SESSION['admin_name']) ? htmlspecialchars($_SESSION['admin_name']) : 'Admin'; ?>
    </div>

    <h1>Data Pengguna</h1>
    <p>Daftar pengguna yang telah mendaftar.</p>

    <table>
      <thead>
        <tr>
          <th>No</th>
          <th>Username</th>
          <th>Nomor Telepon</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $no = 1;
        $query = mysqli_query($conn, "SELECT * FROM users ORDER BY id ASC");
        while ($row = mysqli_fetch_assoc($query)) {
          echo "<tr>";
          echo "<td>" . $no++ . "</td>";
          echo "<td>" . htmlspecialchars($row['username']) . "</td>";
          echo "<td>
                  <a href='edit_user.php?id=" . $row['id'] . "' class='text-primary'>
                    <i class='bi bi-pencil-square'></i> Edit
                  </a> |
                  <a href='hapus_user.php?id=" . $row['id'] . "' class='text-danger' onclick=\"return confirm('Yakin ingin menghapus user ini?')\">
                    <i class='bi bi-trash'></i> Hapus
                  </a>
                </td>";
          echo "</tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</body>
</html>
