<?php
// delete-car.php
include '../koneksi.php';

// Ambil dan sanitasi ID
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id > 0) {
    // Hapus file gambar lama (opsional)
    $stmt = $conn->prepare("SELECT gambar FROM mobil WHERE id_mobil = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($oldImage);
    if ($stmt->fetch() && file_exists(__DIR__ . '/../' . $oldImage)) {
        @unlink(__DIR__ . '/../' . $oldImage);
    }
    $stmt->close();

    // Hapus record
    $stmt = $conn->prepare("DELETE FROM mobil WHERE id_mobil = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// Kembali ke daftar
header("Location: index.php");
exit;
