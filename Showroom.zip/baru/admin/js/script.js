document.addEventListener("DOMContentLoaded", () => {
  const popup = document.getElementById("popup");

  // Cek apakah login berhasil sebelumnya (set dari PHP via localStorage)
  if (localStorage.getItem("loginSuccess") === "true") {
    popup.classList.add("show");

    // Hapus penanda agar tidak muncul lagi saat reload
    localStorage.removeItem("loginSuccess");

    // Sembunyikan popup setelah 3 detik
    setTimeout(() => {
      popup.classList.remove("show");
    }, 3000);
  }
});
