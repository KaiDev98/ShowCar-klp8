<?php include '../koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Kelola Booking Test Drive</title>
  <link rel="stylesheet" href="css/booking-style.css">
</head>
<body>
  <div class="table-container">
    <h2>Daftar Booking Test Drive</h2>
    <table class="custom-table">
      <thead>
        <tr>
          <th>#</th>
          <th>Nama</th>
          <th>Email</th>
          <th>HP</th>
          <th>Waktu</th>
          <th>Mobil</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php
        $q = $conn->query("SELECT * FROM booking_test_drive ORDER BY created_at DESC");
        $i = 1;
        while($r = $q->fetch_assoc()):
      ?>
        <tr>
          <td><?= $i++ ?></td>
          <td><?= htmlspecialchars($r['nama_lengkap']) ?></td>
          <td><?= htmlspecialchars($r['email']) ?></td>
          <td><?= htmlspecialchars($r['no_hp']) ?></td>
          <td><?= date('d-m-Y H:i', strtotime($r['waktu_testdrive'])) ?></td>
          <td><?= htmlspecialchars($r['merk_mobil']) ?></td>
          <td>
            <a href="delete-booking.php?id=<?= $r['id_booking'] ?>"
               onclick="return confirm('Hapus booking ini?')">Hapus</a>
          </td>
        </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
