<?php include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $judul = $_POST['judul'];
  $isi = $_POST['isi'];
  $penulis = $_POST['penulis'];
  $tanggal = date('Y-m-d');

  // Upload Gambar
  $gambar = $_FILES['gambar']['name'];
  $tmp = $_FILES['gambar']['tmp_name'];
  move_uploaded_file($tmp, "../uploads/$gambar");

  $sql = "INSERT INTO berita (judul, isi, gambar, tanggal_publikasi, penulis)
          VALUES ('$judul', '$isi', '$gambar', '$tanggal', '$penulis')";

  mysqli_query($conn, $sql);
  header("Location: index.php");
  exit;
}
?>

<link rel="stylesheet" href="css/tambah-berita.css">
<form method="POST" enctype="multipart/form-data">
  <h2>Tambah Berita</h2>
  Judul:<br><input type="text" name="judul" required><br>
  Isi:<br><textarea name="isi" rows="5" required></textarea><br>
  Gambar:<br><input type="file" name="gambar" accept="image/*" required><br>
  Penulis:<br><input type="text" name="penulis" required><br><br>
  <input type="submit" value="Simpan">
</form>
