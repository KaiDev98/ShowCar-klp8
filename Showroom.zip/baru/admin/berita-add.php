<?php
include '../koneksi.php';
session_start();

if (isset($_POST['submit'])) {
    $judul = $_POST['judul'];
    $kategori = $_POST['kategori'];
    $tanggal = $_POST['tanggal'];
    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];

    move_uploaded_file($tmp, "../uploads/berita/$gambar");

    $query = "INSERT INTO berita (judul, kategori, tanggal, gambar) VALUES ('$judul', '$kategori', '$tanggal', '$gambar')";
    mysqli_query($conn, $query);
    header("Location: berita-list.php");
}
?>
<html>
<head>
  <link rel="stylesheet" href="../assets/css/admin-style.css">
  <title>Tambah Berita</title>
</head>
<body>
  <div class="container">
    <h2>Tambah Berita</h2>
    <form method="POST" enctype="multipart/form-data">
      <label>Judul:</label>
      <input type="text" name="judul" required>

      <label>Kategori:</label>
      <select name="kategori" required>
        <option value="Event">Event</option>
        <option value="Promo">Promo</option>
        <option value="Tips">Tips</option>
        <option value="Trending">Trending</option>
        <option value="CSR">CSR</option>
      </select>

      <label>Tanggal:</label>
      <input type="date" name="tanggal" required>

      <label>Gambar:</label>
      <input type="file" name="gambar" required>

      <button type="submit" name="submit">Simpan</button>
    </form>
  </div>
</body>
</html>