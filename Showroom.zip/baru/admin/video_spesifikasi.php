<?php
// Koneksi DB
$koneksi = new mysqli("localhost", "root", "", "showroom");

// Tambah Video
if (isset($_POST['tambah'])) {
    $judul = $_POST['judul'];
    $link = $_POST['link_video'];
    $deskripsi = $_POST['deskripsi'];
    $koneksi->query("INSERT INTO video_spesifikasi (judul, link_video, deskripsi) VALUES ('$judul', '$link', '$deskripsi')");
    header("Location: video_spesifikasi.php");
}

// Hapus Video
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $koneksi->query("DELETE FROM video_spesifikasi WHERE id = $id");
    header("Location: video_spesifikasi.php");
}

// Ambil data semua video
$data = $koneksi->query("SELECT * FROM video_spesifikasi ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Video Spesifikasi Mobil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light p-5">

<div class="container">
    <h2 class="mb-4">📺 Video Spesifikasi Mobil</h2>

    <!-- Tabel Video -->
    <div class="row">
        <?php while ($row = $data->fetch_assoc()) { ?>
            <div class="col-md-6 mb-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5><?= $row['judul'] ?></h5>
                        <iframe width="100%" height="250" src="<?= $row['link_video'] ?>" frameborder="0" allowfullscreen></iframe>
                        <p class="mt-2"><?= $row['deskripsi'] ?></p>
                        <a href="?hapus=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin?')">Hapus</a>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>

    <hr class="my-5">

    <!-- Form Tambah Video -->
    <h4>➕ Tambah Video Baru</h4>
    <form method="post">
        <div class="mb-3">
            <label>Judul Video</label>
            <input type="text" name="judul" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Link YouTube (Embed)</label>
            <input type="text" name="link_video" class="form-control" placeholder="https://www.youtube.com/embed/ID_VIDEO" required>
        </div>
        <div class="mb-3">
            <label>Deskripsi</label>
            <textarea name="deskripsi" class="form-control" rows="3"></textarea>
        </div>
        <button type="submit" name="tambah" class="btn btn-primary">Simpan</button>
    </form>
</div>

</body>
</html>
