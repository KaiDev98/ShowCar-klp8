<?php
// edit-car.php
include '../koneksi.php';
$alert = "";

// Ambil dan sanitasi ID
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

// Ambil daftar merek & kategori untuk dropdown
$merekResult    = $conn->query("SELECT id_merek, nama_merek FROM merek");
$kategoriResult = $conn->query("SELECT id_kategori, nama_kategori FROM kategori");

// Ambil data mobil yang akan diedit
$stmt = $conn->prepare("
    SELECT nama_mobil, id_merek, id_kategori, harga, stok, gambar, status, video_url 
    FROM mobil 
    WHERE id_mobil = ?
");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($nama_mobil, $id_merek, $id_kategori, $harga, $stok, $oldImage, $status, $video_url);
if (!$stmt->fetch()) {
    // Jika tidak ditemukan
    header("Location: index.php");
    exit;
}
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil input
    $nama_mobil  = trim($_POST['nama_mobil']);
    $id_merek    = (int) $_POST['id_merek'];
    $id_kategori = (int) $_POST['id_kategori'];
    $harga       = (int) $_POST['harga'];
    $stok        = (int) $_POST['stok'];
    $status      = trim($_POST['status']);
    $video_url   = trim($_POST['video_url']);

    // Tangani upload gambar baru (jika ada)
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $tmp      = $_FILES['gambar']['tmp_name'];
        $name     = basename($_FILES['gambar']['name']);
        $newImage = "uploads/" . uniqid() . "_" . $name;
        $fullPath = __DIR__ . '/../' . $newImage;
        if (move_uploaded_file($tmp, $fullPath)) {
            // Hapus file lama
            if (file_exists(__DIR__ . '/../' . $oldImage)) {
                @unlink(__DIR__ . '/../' . $oldImage);
            }
            $imagePath = $newImage;
        } else {
            $alert = "Gagal mengupload gambar baru.";
        }
    } else {
        // Tidak upload baru, pakai gambar lama
        $imagePath = $oldImage;
    }

    // Jika tidak ada error, jalankan UPDATE
    if (!$alert) {
        $sql = "
            UPDATE mobil SET
              nama_mobil  = ?,
              id_merek    = ?,
              id_kategori = ?,
              harga       = ?,
              stok        = ?,
              gambar      = ?,
              status      = ?,
              video_url   = ?
            WHERE id_mobil = ?
        ";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "siiiisssi",
            $nama_mobil,
            $id_merek,
            $id_kategori,
            $harga,
            $stok,
            $imagePath,
            $status,
            $video_url,
            $id
        );
        if ($stmt->execute()) {
            header("Location: index.php");
            exit;
        } else {
            $alert = "Gagal menyimpan perubahan: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Mobil</title>
  <link rel="stylesheet" href="css/edit-car.css">
</head>
<body>
  <div class="container">
    <h1>Edit Mobil</h1>
    <a href="index.php" class="btn-back">← Kembali ke Daftar</a>

    <?php if ($alert): ?>
      <p class="alert"><?= htmlspecialchars($alert) ?></p>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label>Nama Mobil</label>
        <input name="nama_mobil" type="text" value="<?= htmlspecialchars($nama_mobil) ?>" required>
      </div>

      <div class="form-inline">
        <div class="form-group">
          <label>Merek</label>
          <select name="id_merek" required>
            <option value="">-- Pilih Merek --</option>
            <?php while($m = $merekResult->fetch_assoc()): ?>
              <option value="<?= $m['id_merek'] ?>" <?= $m['id_merek']==$id_merek?'selected':''?>>
                <?= htmlspecialchars($m['nama_merek']) ?>
              </option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Kategori</label>
          <select name="id_kategori" required>
            <option value="">-- Pilih Kategori --</option>
            <?php while($k = $kategoriResult->fetch_assoc()): ?>
              <option value="<?= $k['id_kategori'] ?>" <?= $k['id_kategori']==$id_kategori?'selected':''?>>
                <?= htmlspecialchars($k['nama_kategori']) ?>
              </option>
            <?php endwhile; ?>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label>Harga</label>
        <input name="harga" type="number" value="<?= $harga ?>" required>
      </div>

      <div class="form-group">
        <label>Stok</label>
        <input name="stok" type="number" value="<?= $stok ?>" required>
      </div>

      <div class="form-group">
        <label>Status</label>
        <input name="status" type="text" value="<?= htmlspecialchars($status) ?>" required>
      </div>

      <div class="form-group">
        <label>Link Video (opsional)</label>
        <input name="video_url" type="url" value="<?= htmlspecialchars($video_url) ?>">
      </div>

      <div class="form-group">
        <label>Gambar Saat Ini</label><br>
        <img src="<?= htmlspecialchars($oldImage) ?>" alt="" style="max-width:200px;">
      </div>
      <div class="form-group">
        <label>Upload Gambar Baru (opsional)</label>
        <input type="file" name="gambar" accept="image/*">
      </div>

      <button type="submit">Update Mobil</button>
    </form>
  </div>
</body>
</html>
