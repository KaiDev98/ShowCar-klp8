<?php
include '../koneksi.php';
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

$news = $conn->query("SELECT * FROM berita");
?>

<link rel="stylesheet" href="css/style-tabel.css">
<div class="table-container">
  <h2>Data Berita</h2>
  <a href="add-news.php" style="display:inline-block;margin-bottom:10px;color:#2980b9;">+ Tambah Berita</a>
  <table class="custom-table">
    <thead>
      <tr>
        <th>Judul</th>
        <th>Tanggal</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php while($item = $news->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($item['judul']) ?></td>
        <td><?= isset($item['tanggal']) ? $item['tanggal'] : '-' ?></td>
        <td>
          <a href="edit-news.php?id=<?= $item['id'] ?>">Edit</a> |
          <a href="delete-news.php?id=<?= $item['id'] ?>" onclick="return confirm('Hapus berita?')">Hapus</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>
