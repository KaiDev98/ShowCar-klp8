<?php
include '../koneksi.php';
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
$messages = $conn->query("SELECT * FROM messages ORDER BY created_at DESC");
?>
<link href="stylesheet" rel="style-table.css"/>
<h1>Pesan Masuk</h1>
<table border="1">
  <tr>
    <th>Nama</th>
    <th>Email</th>
    <th>Pesan</th>
    <th>Tanggal</th>
  </tr>
  <?php while($msg = $messages->fetch_assoc()): ?>
  <tr>
    <td><?= $msg['nama'] ?></td>
    <td><?= $msg['email'] ?></td>
    <td><?= $msg['pesan'] ?></td>
    <td><?= $msg['created_at'] ?></td>
  </tr>
  <?php endwhile; ?>
</table>
