<?php
include '../koneksi.php';
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
$messages = $conn->query("SELECT * FROM messages ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Pesan Masuk</title>
  <link rel="stylesheet" href="css/style-pesan.css">
</head>
<body>
  <div class="pesan-container">
    <h2>Pesan Masuk</h2>
    <table class="pesan-table">
      <thead>
        <tr>
          <th>Nama</th>
          <th>Email</th>
          <th>Pesan</th>
          <th>Tanggal</th>
        </tr>
      </thead>
      <tbody>
        <?php while($msg = $messages->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($msg['nama']) ?></td>
          <td><?= htmlspecialchars($msg['email']) ?></td>
          <td><?= nl2br(htmlspecialchars($msg['pesan'])) ?></td>
          <td><?= htmlspecialchars($msg['created_at']) ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
