<?php
include '../koneksi.php';
include 'includes/sidebar.php';

$users = $conn->query("SELECT * FROM users");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Pengguna</title>
  <link rel="stylesheet" href="style-table.css">
</head>
<body>
  <div class="content">
    <h2>Data Pengguna</h2>
    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>No</th>
            <th>Username</th>
            <th>Email</th>
            <th>Nomor Kontak</th>
            <th>Tanggal Gabung</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; ?>
          <?php while ($row = $users->fetch_assoc()): ?>
            <tr>
              <td><?= $no++ ?></td>
              <td><?= htmlspecialchars($row['username']) ?></td>
              <td><?= htmlspecialchars($row['email']) ?></td>
              <td><?= htmlspecialchars($row['contact'] ?? '-') ?></td>
              <td><?= htmlspecialchars($row['join_date'] ?? '-') ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
