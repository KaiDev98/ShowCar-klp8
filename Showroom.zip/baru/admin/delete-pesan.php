<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
include '../koneksi.php';

$id = $_GET['id'];
$conn->query("DELETE FROM kontak WHERE id = $id");

header("Location: index.php");
?>
