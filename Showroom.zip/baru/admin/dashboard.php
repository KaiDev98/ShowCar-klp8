<?php
session_start();
if (!isset($_SESSION['admin_name'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin | Showroom Mobil</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- External CSS -->
  <link rel="stylesheet" href="css/style.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
</head>
<body>

<!-- Navbar -->
<nav class="navbar">
  <div class="navbar-left">
    <span class="navbar-brand">ShowCar Admin</span>
  </div>
  <div class="navbar-right">
    <span class="user-greeting">Halo, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
    <a href="logout.php" class="logout-btn">Logout</a>
  </div>
</nav>

<div class="main-container">
  <!-- Sidebar -->
  <aside class="sidebar">
    <h4>Menu</h4>
    <a href="dashboard.php">Dashboard</a>
    <a href="users.php">Data Pengguna</a>
    <a href="data_mobil.php">Data Mobil</a>
    <a href="berita.php">Berita</a>
    <a href="diskusi.php">Diskusi</a>
    <a href="review.php">Review & Rating</a>
    <a href="data_pembelian.php">Data Pembelian</a>
  </aside>

  <!-- Main content -->
  <main class="content">
    <h2>Selamat Datang di Dashboard Admin</h2>
    <div class="dashboard-panels">
      <!-- Contoh Panel -->
      <div class="panel blue">
        <div class="panel-body">
          <div class="stat-number">24</div>
          <div class="stat-title">Mobil Tersedia</div>
        </div>
        <a href="data_mobil.php" class="panel-footer">Lihat Detail <i class="fa fa-arrow-right"></i></a>
      </div>
      <!-- Tambah panel lainnya sesuai kebutuhan -->
    </div>
  </main>
</div>

<!-- JS -->
<script src="js/script.js"></script>
</body>
</html>
