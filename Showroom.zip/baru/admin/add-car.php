<?php
// add-car.php
include '../koneksi.php';

$alert = "";

// Ambil data merek & kategori untuk dropdown
$merekResult    = $conn->query("SELECT id_merek, nama_merek FROM merek");
$kategoriResult = $conn->query("SELECT id_kategori, nama_kategori FROM kategori");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Tangkap input
    $nama_mobil   = trim($_POST['nama_mobil']);
    $id_merek     = (int) $_POST['id_merek'];
    $id_kategori  = (int) $_POST['id_kategori'];
    $harga        = (int) $_POST['harga'];
    $stok         = (int) $_POST['stok'];
    $status       = trim($_POST['status']);
    $video_url    = trim($_POST['video_url']);

    // Validasi foreign key merek
    $cekMerek = $conn->prepare("SELECT 1 FROM merek WHERE id_merek = ?");
    $cekMerek->bind_param("i", $id_merek);
    $cekMerek->execute();
    $cekMerek->store_result();
    if ($cekMerek->num_rows === 0) {
        $alert = "Merek tidak valid.";
    }

    // Validasi foreign key kategori
    $cekKategori = $conn->prepare("SELECT 1 FROM kategori WHERE id_kategori = ?");
    $cekKategori->bind_param("i", $id_kategori);
    $cekKategori->execute();
    $cekKategori->store_result();
    if ($cekKategori->num_rows === 0) {
        $alert = "Kategori tidak valid.";
    }

    // Jika validasi OK, lanjut upload dan INSERT
    if (!$alert) {
        // Upload gambar
        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $imageName = $_FILES['gambar']['name'];
            $imageTmp  = $_FILES['gambar']['tmp_name'];
            $imagePath = "uploads/" . uniqid() . "_" . basename($imageName);
            $fullPath  = __DIR__ . '/../' . $imagePath;

            if (move_uploaded_file($imageTmp, $fullPath)) {
                // Siapkan dan jalankan INSERT
                $sql = "INSERT INTO mobil 
                          (nama_mobil, id_merek, id_kategori, harga, stok, gambar, status, video_url) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param(
                    "siiiisss",
                    $nama_mobil,
                    $id_merek,
                    $id_kategori,
                    $harga,
                    $stok,
                    $imagePath,
                    $status,
                    $video_url
                );
                if ($stmt->execute()) {
                    $alert = "Mobil berhasil ditambahkan!";
                } else {
                    $alert = "Gagal menyimpan data: " . $stmt->error;
                }
            } else {
                $alert = "Gagal mengupload gambar.";
            }
        } else {
            $alert = "Mohon pilih file gambar.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tambah Mobil</title>
  <link rel="stylesheet" href="css/add-car.css">
</head>
<body>

  <!-- Tombol Close (X) -->
  <a href="index.php" class="btn-back"></a>

  <?php if ($alert): ?>
  <script>
    alert("<?= addslashes($alert) ?>");
    <?php if (str_contains($alert, 'berhasil')): ?>
      window.location.href = "index.php";
    <?php endif; ?>
  </script>
  <?php endif; ?>

  <div class="container">
    <h1>Tambah Mobil Baru</h1>

    <form method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label>Nama Mobil</label>
        <input name="nama_mobil" type="text" placeholder="Masukkan nama mobil" required>
      </div>

      <div class="form-inline">
        <div class="form-group">
          <label>Merek</label>
          <select name="id_merek" required>
            <option value="">-- Pilih Merek --</option>
            <?php while($m = $merekResult->fetch_assoc()): ?>
            <option value="<?= $m['id_merek'] ?>">
              <?= htmlspecialchars($m['nama_merek']) ?>
            </option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Kategori</label>
          <select name="id_kategori" required>
            <option value="">-- Pilih Kategori --</option>
            <?php while($k = $kategoriResult->fetch_assoc()): ?>
            <option value="<?= $k['id_kategori'] ?>">
              <?= htmlspecialchars($k['nama_kategori']) ?>
            </option>
            <?php endwhile; ?>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label>Harga</label>
        <input name="harga" type="number" placeholder="Masukkan harga dalam Rupiah" required>
      </div>

      <div class="form-group">
        <label>Stok</label>
        <input name="stok" type="number" placeholder="Jumlah stok tersedia" required>
      </div>

      <div class="form-group">
        <label>Status</label>
        <select name="status" required>
          <option value="">-- Pilih Status --</option>
          <option value="tersedia">Tersedia</option>
          <option value="terjual">Terjual</option>
          <option value="booking">Booking</option>
        </select>
      </div>

      <div class="form-group">
        <label>Link Video (opsional)</label>
        <input name="video_url" type="url" placeholder="https://youtube.com/watch?v=...">
      </div>

      <div class="form-group">
        <label>Gambar</label>
        <input type="file" name="gambar" accept="image/*" required>
      </div>
      <button type="submit">Simpan Mobil</button>
    </form>
  </div>

</body>
</html>