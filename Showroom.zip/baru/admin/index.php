<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}
?>


<?php
$koneksi = new mysqli("localhost", "root", "", "showroom");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard Admin | Showroom Mobil</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #f1f3f5;
      font-family: "Segoe UI", sans-serif;
    }
    .navbar {
      background-color: #343a40;
    }
    .navbar-brand {
      color: white;
      font-weight: bold;
    }
    .navbar-brand:hover {
      color: #ffc107;
    }
    .sidebar {
      background-color: #212529;
      min-height: 100vh;
      padding-top: 20px;
      color: white;
    }
    .sidebar a {
      color: #adb5bd;
      padding: 10px 20px;
      display: block;
      text-decoration: none;
    }
    .sidebar a:hover {
      background-color: #343a40;
      color: #fff;
    }
    .panel {
      border-radius: 10px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
      overflow: hidden;
    }
    .panel-body {
      padding: 20px;
      color: white;
      text-align: center;
    }
    .panel-footer {
      background-color: rgba(0, 0, 0, 0.05);
      padding: 10px;
      text-align: center;
      color: #000;
      font-weight: 600;
      display: block;
      text-decoration: none;
    }
    .stat-panel-number {
      font-size: 32px;
      font-weight: bold;
    }
    .stat-panel-title {
      text-transform: uppercase;
      font-size: 14px;
      margin-top: 5px;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <a class="navbar-brand" href="#">ShowCar Admin</a>
  <div class="ml-auto">
    <span class="navbar-text mr-3">
      Halo, <?php echo isset($_SESSION['admin_name']) 
    ? htmlspecialchars($_SESSION['admin_name']) 
    : 'Admin'; 
?>

    </span>
    <a href="logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
  </div>
</nav>

<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <div class="sidebar col-md-2">
      <h4 class="text-center">Menu</h4>
      <nav class="nav flex-column">
        <a class="nav-link" href="index.php">Dashboard</a>
        <a class="nav-link" href="car.php">Mobil</a>
        <a class="nav-link" href="users.php">Pengguna</a>
        <a class="nav-link" href="news.php">Berita</a>
        <!-- <a class="nav-link" href="messages.php">Pesan</a> -->
        <a class="nav-link" href="bookings.php">Booking</a>
      </nav>
    </div>

    <!-- Main content -->
    <main class="col-md-10 content mt-4">
      <h2 class="mb-4">Dashboard Admin Showroom</h2>

      <div class="row">
        <!-- Panel 1 -->
        <div class="col-md-4 mb-4">
          <div class="panel bg-primary">
            <div class="panel-body">
              <div class="stat-panel-number">24</div>
              <div class="stat-panel-title">Pengguna</div>
            </div>
            <a href="users.php" class="panel-footer text-dark">
              Lihat Detail <i class="fa fa-arrow-right"></i>
            </a>
          </div>
        </div>

        <!-- Panel 2 -->
        <div class="col-md-4 mb-4">
          <div class="panel bg-success">
            <div class="panel-body">
              <div class="stat-panel-number">15</div>
              <div class="stat-panel-title">Mobil</div>
            </div>
            <a href="car.php" class="panel-footer text-dark">
              Lihat Detail <i class="fa fa-arrow-right"></i>
            </a>
          </div>
        </div>

        <!-- Panel 3 -->
        <div class="col-md-4 mb-4">
          <div class="panel bg-danger">
            <div class="panel-body">
              <div class="stat-panel-number">3</div>
              <div class="stat-panel-title">Berita</div>
            </div>
            <a href="news.php" class="panel-footer text-dark">
              Lihat Detail <i class="fa fa-arrow-right"></i>
            </a>
          </div>
        </div>

        <!-- Panel 4 -->
        <div class="col-md-4 mb-4">
          <div class="panel bg-warning">
            <div class="panel-body">
              <div class="stat-panel-number">6</div>
              <div class="stat-panel-title">Booking</div>
            </div>
            <a href="users.php" class="panel-footer text-dark">
              Lihat Detail <i class="fa fa-arrow-right"></i>
            </a>
          </div>
        </div>

        <!-- Panel 5 -->
        <!-- <div class="col-md-4 mb-4">
          <div class="panel bg-info">
            <div class="panel-body">
              <div class="stat-panel-number">4</div>
              <div class="stat-panel-title">Pesan</div>
            </div>
            <a href="kategori.php" class="panel-footer text-dark">
              Lihat Detail <i class="fa fa-arrow-right"></i>
            </a>
          </div>
        </div>       -->
    </main>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
