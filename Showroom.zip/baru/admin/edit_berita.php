<?php
include '../koneksi.php';
$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM berita WHERE id = $id"));

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $judul = $_POST['judul'];
  $isi = $_POST['isi'];
  $penulis = $_POST['penulis'];

  if ($_FILES['gambar']['name'] != '') {
    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];
    move_uploaded_file($tmp, "../uploads/$gambar");
    $update = "UPDATE berita SET judul='$judul', isi='$isi', gambar='$gambar', penulis='$penulis' WHERE id=$id";
  } else {
    $update = "UPDATE berita SET judul='$judul', isi='$isi', penulis='$penulis' WHERE id=$id";
  }

  mysqli_query($conn, $update);
  header("Location: index.php");
  exit;
}
?>

<form method="POST" enctype="multipart/form-data">
  <h2>Edit Berita</h2>
  Judul:<br><input type="text" name="judul" value="<?= $data['judul']; ?>"><br>
  Isi:<br><textarea name="isi" rows="5"><?= $data['isi']; ?></textarea><br>
  Gambar:<br><input type="file" name="gambar" accept="image/*"><br>
  Penulis:<br><input type="text" name="penulis" value="<?= $data['penulis']; ?>"><br><br>
  <input type="submit" value="Update">
</form>
