// File: admin/berita-edit.php
<?php
include '../koneksi.php';
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_GET['id'];
$query = mysqli_query($conn, "SELECT * FROM berita WHERE id=$id");
$data = mysqli_fetch_assoc($query);

if (isset($_POST['submit'])) {
    $judul = $_POST['judul'];
    $kategori = $_POST['kategori'];
    $tanggal = $_POST['tanggal'];
    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];

    if ($gambar) {
        move_uploaded_file($tmp, "../uploads/berita/$gambar");
        $update = "UPDATE berita SET judul='$judul', kategori='$kategori', tanggal='$tanggal', gambar='$gambar' WHERE id=$id";
    } else {
        $update = "UPDATE berita SET judul='$judul', kategori='$kategori', tanggal='$tanggal' WHERE id=$id";
    }
    mysqli_query($conn, $update);
    header("Location: berita-list.php");
}
?>
<html>
<head>
  <link rel="stylesheet" href="../assets/css/admin-style.css">
  <title>Edit Berita</title>
</head>
<body>
  <div class="container">
    <h2>Edit Berita</h2>
    <form method="POST" enctype="multipart/form-data">
      <label>Judul:</label>
      <input type="text" name="judul" value="<?= $data['judul'] ?>" required>

      <label>Kategori:</label>
      <select name="kategori" required>
        <option <?= $data['kategori'] == 'Event' ? 'selected' : '' ?>>Event</option>
        <option <?= $data['kategori'] == 'Promo' ? 'selected' : '' ?>>Promo</option>
        <option <?= $data['kategori'] == 'Tips' ? 'selected' : '' ?>>Tips</option>
        <option <?= $data['kategori'] == 'Trending' ? 'selected' : '' ?>>Trending</option>
        <option <?= $data['kategori'] == 'CSR' ? 'selected' : '' ?>>CSR</option>
      </select>

      <label>Tanggal:</label>
      <input type="date" name="tanggal" value="<?= $data['tanggal'] ?>" required>

      <label>Gambar Baru (Opsional):</label>
      <input type="file" name="gambar">

      <button type="submit" name="submit">Update</button>
    </form>
  </div>
</body>
</html>