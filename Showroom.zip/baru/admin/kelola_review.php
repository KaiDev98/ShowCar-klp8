<?php include 'koneksi.php'; ?>

<link href="stylesheet" rel="style-table.css"/>
<h2>Kelola Review</h2>
<table border="1" cellpadding="10">
<tr><th>No</th><th>Nama</th><th>Mobil</th><th>Rating</th><th>Komentar</th><th>Aksi</th></tr>
<?php
$res = $conn->query("SELECT r.*, m.nama AS nama_mobil FROM review r JOIN mobil m ON r.mobil_id = m.id");
$no = 1;
while($r = $res->fetch_assoc()) {
    echo "<tr>
        <td>$no</td>
        <td>{$r['nama']}</td>
        <td>{$r['nama_mobil']}</td>
        <td>{$r['rating']}</td>
        <td>{$r['komentar']}</td>
        <td><a href='hapus_review.php?id={$r['id']}'>Hapus</a></td>
    </tr>";
    $no++;
}
?>
</table>
