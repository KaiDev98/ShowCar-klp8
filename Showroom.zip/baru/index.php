<?php include 'db.php'; ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ShowCar</title>
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT"
      crossorigin="anonymous"
    />
    <link href="assets/css/style.css" rel="stylesheet"/>
  </head>
  <body id="home">
    <!-- NAVBAR -->
    <nav
      class="navbar navbar-expand-lg navbar-light bg-white shadow-sm py-3 fixed-top"
    >
      <div class="container">
        <a class="navbar-brand font-weight-bold text-danger" href="#"
          >ShowCar</a
        >
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarNav"
        >
          <ul class="navbar-nav">
            <li class="nav-item mx-2">
              <a class="nav-link" href="#home">Home</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="#shop">Shop</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="#contact">Contact</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="#faqs">Faqs</a>
            </li>
            <li class="nav-item mx-2">
              <a class="nav-link" href="diskusi.php">Diskusi</a>
            </li>
          </ul>
          <div class="ml-3">
            <a href="login.php" class="btn btn-outline-danger mx-1">Login</a>
            <a href="register.php" class="btn btn-danger mx-1">Register</a>
          </div>
        </div>
      </div>
    </nav>
    <!-- akhiran navbar -->

    <!-- section -->
         <section class="hero">
      <div class="blur-overlay"></div>
      <div class="vertical-text">Show New Car</div>
      <div class="hero-content">
        <p class="tagline">/ Car In Easy Steps</p>
        <h1 class="title">
          Perfeet Way To Buy<br />And Sell Car On Our Platform
        </h1>
        <div class="cta-buttons">
          <button class="btn red" onclick="window.location.href='#porsche'">
            Explore Car
          </button>
          <button class="btn outline" onclick="window.location.href='#shop'">
            Buy Car
          </button>
        </div>
        <div class="icons">
          <span class="social-text">We are in social media :</span>
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
        </div>
      </div>
    </section>
    <!-- akhiran section -->

    <!-- awalan feature -->
    <section class="feature-row">
      <div class="feature-row">
        <!-- Box 1 -->
        <div class="feature-box box-1">
          <div class="feature-content">
            <h5>Fast Approval</h5>
            <p>
              Quick and simple approval process for car buyers with our advanced
              tools available now.
            </p>
            <a href="#shop" class="feature-btn">Buy Car <span>➜</span></a>
          </div>
          <div class="big-number">01</div>
        </div>

        <!-- Box 2 -->
        <div class="feature-box box-2 with-bg">
          <div class="feature-content"></div>
        </div>

        <!-- Box 3 -->
        <div class="feature-box box-3">
          <div class="feature-content">
            <h5>User Friendly</h5>
            <p>
              Easy navigation and seamless user experience for everyone who
              needs a car solution.
            </p>
            <a href="#shop" class="feature-btn">Buy Car <span>➜</span></a>
          </div>
          <div class="big-number">02</div>
        </div>

        <!-- Box 4 -->
        <div class="feature-box box-4 with-bg">
          <div class="feature-content"></div>
        </div>
      </div>
    </section>
    <!-- akhiran feature  -->

    <!-- porsche highlight -->
    <div id="porsche" class="porsche">
      <img src="assets/img/porsche.avif" alt="Red Porsche" class="car-image" />
      <div class="text-porsche">
        <h4 class="sub-title">Brent New Car</h4>
        <h1 class="main-title">Feel The Power<br />Of Porsche.</h1>
        <p>
          A Porsche is as individual as its owner. It is always an expression of
          one’s own personality. We help you find your personal dream vehicle
          from authorised Porsche Centres.
        </p>
        <a href="https://en.wikipedia.org/wiki/Porsche" class="button-porsche"
          >Read To More <span>&rarr;</span></a
        >
      </div>
    </div>
    <!-- akhiran porsche -->

    <!-- brand logo -->
    <div class="brand-row">
      <a href="https://www.chevrolet.com" target="_blank">
        <img
          src="https://static.vecteezy.com/system/resources/previews/020/498/757/original/chevrolet-brand-logo-car-symbol-with-name-white-design-usa-automobile-illustration-with-black-background-free-vector.jpg"
          alt="Chevrolet"
        />
      </a>

      <a href="https://www.jeep.com" target="_blank">
        <img
          src="https://tse4.mm.bing.net/th?id=OIP.jz71Zina4ioOEgRTtmB_YgHaE8&pid=Api&P=0&h=180"
          alt="Jeep"
        />
      </a>

      <a href="https://www.mitsubishi-motors.com" target="_blank">
        <img
          src="https://tse3.mm.bing.net/th?id=OIP.jsJs9t1UXntOqAfG06DqsAHaGB&pid=Api&P=0&h=180"
          alt="Mitsubishi"
        />
      </a>

      <a href="https://www.tesla.com" target="_blank">
        <img
          src="https://tse3.mm.bing.net/th?id=OIP.11aeOv9S0j4jTrUQRWbj7QHaHa&pid=Api&P=0&h=180"
          alt="Tesla"
        />
      </a>

      <a href="https://www.mercedes-benz.com" target="_blank">
        <img
          src="https://static.vecteezy.com/ti/vetor-gratis/p1/20502492-mercedes-benz-marca-logotipo-simbolo-com-nome-branco-projeto-alemao-carro-automovel-ilustracao-com-preto-fundo-gratis-vetor.jpg"
          alt="Mercedes-Benz"
        />
      </a>

      <a href="https://www.rolls-roycemotorcars.com" target="_blank">
        <img
          src="https://tse2.mm.bing.net/th?id=OIP.3f5e_4vMl8rbWQ7DiWVkGgHaGB&pid=Api&P=0&h=180"
          alt="Rolls-Royce"
        />
      </a>

      <a href="https://www.hummer.com" target="_blank">
        <img
          src="https://tse2.mm.bing.net/th?id=OIP.otaRtMs1k5u17mBQhOnHKgHaGB&pid=Api&P=0&h=180"
          alt="Hummer"
        />
      </a>
    </div>
    <!-- akhiran logo -->

    <!-- car -->
     <section id="shop" class="popular-cars">
  <p class="subtitle">New Popular Car</p>
  <h2 class="title">Shop Populer New Car</h2>

  <div class="filters">
    <button class="filter-btn active" data-filter="all">Show All</button>
    <?php
      // Ambil distinct nama merek
      $brands = $conn->query("
        SELECT DISTINCT mr.nama_merek
        FROM mobil m
        JOIN merek mr ON m.id_merek = mr.id_merek
      ");
      while ($b = $brands->fetch_assoc()):
        $brandName = htmlspecialchars($b['nama_merek']);
    ?>
        <button class="filter-btn" data-filter="<?= $brandName ?>">
          <?= $brandName ?>
        </button>
    <?php endwhile; ?>
  </div>

  <div class="car-grid">
    <?php
      // Ambil semua mobil beserta nama merek & kategori
      $cars = $conn->query("
        SELECT
          m.id_mobil,
          m.nama_mobil,
          mr.nama_merek,
          k.nama_kategori,
          m.harga,
          m.stok,
          m.status,
          m.gambar
        FROM mobil m
        JOIN merek mr ON m.id_merek = mr.id_merek
        JOIN kategori k ON m.id_kategori = k.id_kategori
        WHERE m.status = 'tersedia'
        ORDER BY m.id_mobil DESC
      ");
      while ($row = $cars->fetch_assoc()):
        $id        = (int)$row['id_mobil'];
        $name      = htmlspecialchars($row['nama_mobil']);
        $brand     = htmlspecialchars($row['nama_merek']);
        $category  = htmlspecialchars($row['nama_kategori']);
        $price     = number_format($row['harga'], 0, ',', '.');
        $stock     = (int)$row['stok'];
        $status    = htmlspecialchars($row['status']);
        $imgSrc    = htmlspecialchars($row['gambar']);
    ?>
      <div class="car-card" data-brand="<?= $brand ?>">
        <img src="<?= $imgSrc ?>" alt="<?= $name ?>" />
        <div class="car-info">
          <div class="car-header">
            <h3><?= $name ?></h3>
            <i class="fa-solid fa-heart heart"></i>
          </div>
          <p class="car-type"><?= $category ?></p>
          <p class="description">Stok tersedia: <?= $stock ?></p>
          <div class="specs">
            <span>Brand: <?= $brand ?></span>
            <span>Status: <?= $status ?></span>
          </div>
          <div class="price-row">
            <span class="price">Rp<?= $price ?></span>
            <a href="detail_mobil.php?id=<?= $id ?>">
              <button class="buy">Buy Now</button>
            </a>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
</section>
    <!-- akhiran car -->

    <!-- awalan konten car -->
    <div class="custom-container">
      <div class="row">
        <!-- Left Column -->
        <div class="col-lg-4 mb-4">
          <div class="left">
            <h1>Our For Return<br />Special For Your</h1>
            <p>
              Lorem Ipsum Dolor Sit Amet Consectetur. Consectetur Turpis In A
              Facilisis. Semper Aliquam Egestas Faucibus Ornare Massa Morbi
              Tincidunt Quam Felis. Sagittis Hac Elit Euismod.
            </p>
            <div class="indicator">
              <div class="active" data-index="0"></div>
              <div data-index="1"></div>
              <div data-index="2"></div>
            </div>
          </div>
        </div>

        <!-- Right Column -->
        <div class="col-lg-8">
          <div class="row g-3">
            <div class="col-md-4 card-wrapper active" data-index="0">
              <div class="card-custom">
                <img
                  src="https://images.unsplash.com/photo-1675058860685-bee32b81395b?w=600&auto=format&fit=crop&q=60"
                  alt="Car"
                />
                <h3>Nissan</h3>
                <h4>RT 20</h4>
                <p>
                  Lorem Ipsum Dolor Sit Amet Consectetur. Ut Sit Nullam
                  Elementum Nunc Dolor Lobortis Pellentesque Mattis. Sit
                  Pellentesque Massa.
                </p>
              </div>
            </div>
            <div class="col-md-4 card-wrapper" data-index="1">
              <div class="card-custom">
                <img
                  src="https://images.unsplash.com/photo-1490902931801-d6f80ca94fe4?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTV8fGNhcnxlbnwwfHwwfHx8MA%3D%3D"
                  alt="Car"
                />
                <h3>Toyota</h3>
                <h4>GT 86</h4>
                <p>
                  Toyota Sports Car With Sleek Design And Performance. Speed
                  Meets Elegance In Every Turn.
                </p>
              </div>
            </div>
            <div class="col-md-4 card-wrapper" data-index="2">
              <div class="card-custom">
                <img
                  src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fGNhcnxlbnwwfHwwfHx8MA%3D%3D"
                  alt="Car"
                />
                <h3>BMW</h3>
                <h4>M4 Series</h4>
                <p>
                  Experience The Power And Luxury Of The BMW M4. Built For
                  Driving Enthusiasts.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- akhiran konten car -->

    <!-- pesan -->
    <section id="contact">
      <div class="container">
        <div class="row text-center mb-4">
          <div class="col">
            <h2 style="font-weight: bold; text-align: center; margin-top: 20px">
              Contact Us
            </h2>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-md-6">
            <form action="simpan_kontak.php" method="POST">
              <div class="mb-3">
                <label for="name" class="form-label">Nama lengkap</label>
                <input
                  type="text"
                  class="form-control"
                  id="name"
                  name="name"
                  required
                />
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input
                  type="email"
                  class="form-control"
                  id="email"
                  name="email"
                  required
                />
              </div>
              <div class="mb-3">
                <label for="pesan" class="form-label">Pesan</label>
                <textarea
                  class="form-control"
                  id="pesan"
                  name="pesan"
                  rows="3"
                  required
                ></textarea>
              </div>
              <div class="text-center">
                <button type="submit" class="btn btn-danger px-4">Kirim</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
    <!-- akhiran pesan -->

    <!-- FAQ -->
    <section id="faqs" class="faq-container">
      <div class="faq-left">
        <h2>FAQs</h2>
        <div class="faq-item active">
          <div class="faq-question">
            <h5>Apa itu ShowCar?</h5>
            <span class="icon">−</span>
          </div>
          <div class="faq-answer">
            <p>ShowCar Merupakan platform penjualan mobil secara Online</p>
          </div>
        </div>

        <div class="faq-item">
          <div class="faq-question">
            <h5>Bagaimana saya dapat menghubungi ShowCar?</h5>
            <span class="icon">+</span>
          </div>
          <div class="faq-answer">
            <p>Anda dapat menghubungi nomor kami 82075289374</p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question">
            <h5>Bagaimana saya dapat memesan mobil secara online?</h5>
            <span class="icon">-</span>
          </div>
          <div class="faq-answer">
            <p>
              Silahkan kunjungi website resmi Showcar. Lakukan login / regist,
              pilih mobil, isi data sesuai petunju, dan lakukan pemesanan.
              Silahkan tunggu tim kami menghubungi anda.
            </p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question">
            <h5>Bagaimana cara melihat detail mobil?</h5>
            <span class="icon">+</span>
          </div>
          <div class="faq-answer">
            <p>
              Silahkan login atau regist dan buttuon buy pada mobil untuk
              melihat detail
            </p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question">
            <h5>Apakah Showcar menjual mobil baru?</h5>
            <span class="icon">-</span>
          </div>
          <div class="faq-answer">
            <p>Showcar hanya menjual mobil baru.</p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question">
            <h5>Apakah saya perlu mendaftar akun?</h5>
            <span class="icon">+</span>
          </div>
          <div class="faq-answer">
            <p>Ya, anda butuh akun jika ingin membeli mobil baru.</p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question">
            <h5>Apakah bisa melakukan test drive?</h5>
            <span class="icon">-</span>
          </div>
          <div class="faq-answer">
            <p>Anda dapat melakukan test drive jika membeli mobil</p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question">
            <h5>Bagaimana mengetahui mobil masih tersedia?</h5>
            <span class="icon">+</span>
          </div>
          <div class="faq-answer">
            <p>Jika mobil masih tampil di website, mobil masih tersedia</p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question">
            <h5>Apakah Showcar melayani seluruh Indonesia?</h5>
            <span class="icon">-</span>
          </div>
          <div class="faq-answer">
            <p>Showcar hanya melayani kota Pare pare dan sekitarnya</p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question">
            <h5>
              Bagaimana saya tahu status pemesanan mobil yang akan dibeli?
            </h5>
            <span class="icon">+</span>
          </div>
          <div class="faq-answer">
            <p>
              Akan muncul konfirmasi di halaman website bahwa anda telah
              melakukan pemesanan dan silahkan tunggu tim kami menghubungi anda.
            </p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question">
            <h5>Bagaimana metode pembayaran di Showcar?</h5>
            <span class="icon">-</span>
          </div>
          <div class="faq-answer">
            <p>
              Anda dapat melakukan di toko fisik, baik tunai maupun non tunai.
            </p>
          </div>
        </div>
        <div class="faq-item">
          <div class="faq-question">
            <h5>Bagaimana saya dapat menghubungi layanan service ShowCar?</h5>
            <span class="icon">+</span>
          </div>
          <div class="faq-answer">
            <p>Anda dapat menghubungi nomor kami 82075289374</p>
          </div>
        </div>

        <!-- Tambah item lainnya sesuai kebutuhan -->
      </div>

      <div class="faq-right">
        <div class="image-container">
          <img src="assets/img/footer.jpg" alt="ShowCar" />
        </div>
        <div class="overlay-text">
          <span>Show</span><span class="highlight">Car</span>
        </div>
      </div>
    </section>
    <!-- akhiran faq -->

    <!-- Footer Start -->
    <footer>
      <div class="footer-section">
        <div class="container footer-flex">
          <!-- Left: Logo, Description, Social -->
          <div class="footer-left">
            <h2 class="footer-logo">ShowCar</h2>
            <p class="footer-description">Hubungi Juga kami di sosial Media</p>
            <div class="footer-right">
              <a href="#"><i class="fab fa-facebook-f"></i></a>
              <a href="#"><i class="fab fa-twitter"></i></a>
              <a href="#"><i class="fab fa-instagram"></i></a>
              <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
          </div>
        </div>
      </div>

      <div class="footer-bottom">
        <p>Di Buat Oleh Rifki. Menggunakan Tailwind Css Dan Js</p>
      </div>
    </footer>
    <!-- Footer End -->

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
    <script>
      const indicators = document.querySelectorAll(".indicator div");
      const cards = document.querySelectorAll(".card-wrapper");

      indicators.forEach((indicator) => {
        indicator.addEventListener("click", () => {
          const index = indicator.dataset.index;

          // Update active indicator
          indicators.forEach((i) => i.classList.remove("active"));
          indicator.classList.add("active");

          // Switch cards with animation
          cards.forEach((card) => {
            if (card.dataset.index === index) {
              card.classList.add("active");
            } else {
              card.classList.remove("active");
            }
          });
        });
      });
    </script>
  </body>
</html>
