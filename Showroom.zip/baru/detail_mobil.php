<?php
include 'config.php';

if (!isset($_GET['id'])) {
  header('Location: index.php');
  exit;
}

$id = intval($_GET['id']);
$result = $conn->query("
  SELECT m.*, mr.nama_merek, k.nama_kategori
  FROM mobil m
  JOIN merek mr ON m.id_merek = mr.id_merek
  JOIN kategori k ON m.id_kategori = k.id_kategori
  WHERE m.id_mobil = $id
");

if ($result->num_rows == 0) {
  echo "Mobil tidak ditemukan.";
  exit;
}

$data = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title><?= $data['nama_mobil'] ?></title>
  <link rel="stylesheet" href="assets/css/detail-mobil.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<div class="detail-container">
  <div class="image-section">
    <img src="<?= htmlspecialchars($data['gambar']) ?>" alt="<?= htmlspecialchars($data['nama_mobil']) ?>">
  </div>

  <div class="info-section">
    <h2><?= htmlspecialchars($data['nama_mobil']) ?></h2>
    <p><strong><?= htmlspecialchars($data['nama_merek']) ?></strong> • <?= htmlspecialchars($data['nama_kategori']) ?></p>
    <p class="price">Rp <?= number_format($data['harga'], 0, ',', '.') ?></p>

    <div class="specs">
      <div class="spec-item"><i class="fas fa-gas-pump"></i> <?= htmlspecialchars($data['bahan_bakar'] ?? 'Bensin') ?></div>
      <div class="spec-item"><i class="fas fa-cogs"></i> <?= htmlspecialchars($data['transmisi'] ?? 'Manual') ?></div>
      <div class="spec-item"><i class="fas fa-chair"></i> <?= htmlspecialchars($data['kursi'] ?? '5') ?> Kursi</div>
      <div class="spec-item"><i class="fas fa-cube"></i> <?= htmlspecialchars($data['kapasitas'] ?? '1.5L') ?></div>
    </div>

    <div class="buy-box">
    <p><strong>Stok:</strong> <?= $data['stok'] ?> unit</p>
    <p><strong>Status:</strong> <?= $data['status'] ?></p>
    <p>
        Hubungi staff kami :
        <a href="https://wa.me/6289525051006" target="_blank" style="margin-left:8px; color:#25D366; text-decoration:none; font-weight:bold;">
        <i class="fab fa-whatsapp" style="font-size:1.2em;"></i> 0895-2505-1006
        </a>
    </p>
    </div>
  </div>
</div>

<!-- VIDEO SPESIFIKASI -->
<div class="video-section">
  <h3>Video Spesifikasi</h3>
  <?php if (!empty($data['video_url'])):
    // Ekstrak ID video dari YouTube URL
    parse_str(parse_url($data['video_url'], PHP_URL_QUERY), $ytParams);
    $videoId = $ytParams['v'] ?? null;
    if ($videoId): ?>
      <div class="video-wrapper">
        <iframe width="100%" height="400" 
                src="https://www.youtube.com/embed/<?= htmlspecialchars($videoId) ?>" 
                frameborder="0" allowfullscreen>
        </iframe>
      </div>
    <?php else: ?>
      <p>Link video tidak valid.</p>
    <?php endif; ?>
  <?php else: ?>
    <p>Video spesifikasi belum tersedia untuk mobil ini.</p>
  <?php endif; ?>
</div>

</body>
</html>
